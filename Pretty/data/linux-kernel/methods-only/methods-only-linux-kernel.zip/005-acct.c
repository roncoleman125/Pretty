static void close_work(struct work_struct *work)
{
        struct bsd_acct_struct *acct = container_of(work, struct bsd_acct_struct, work);
        struct file *file = acct->file;
        if (file->f_op->flush)
                file->f_op->flush(file, NULL);
        __fput_sync(file);
        complete(&acct->done);
}

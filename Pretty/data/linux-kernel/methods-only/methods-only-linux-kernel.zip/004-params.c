static char dash2underscore(char c)
{
        if (c == '-')
                return '_';
        return c;
}

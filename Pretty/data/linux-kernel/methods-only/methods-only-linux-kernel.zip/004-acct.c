static void acct_pin_kill(struct fs_pin *pin)
{
        struct bsd_acct_struct *acct = to_acct(pin);
        mutex_lock(&acct->lock);
        do_acct_process(acct);
        schedule_work(&acct->work);
        wait_for_completion(&acct->done);
        cmpxchg(&acct->ns->bacct, pin, NULL);
        mutex_unlock(&acct->lock);
        pin_remove(pin);
        acct_put(acct);
}

/*
 * Called from unshare. Unshare all the namespaces part of nsproxy.
 * On success, returns the new nsproxy.
 */
int unshare_nsproxy_namespaces(unsigned long unshare_flags,
        struct nsproxy **new_nsp, struct cred *new_cred, struct fs_struct *new_fs)
{
        struct user_namespace *user_ns;
        int err = 0;

        if (!(unshare_flags & (CLONE_NEWNS | CLONE_NEWUTS | CLONE_NEWIPC |
                               CLONE_NEWNET | CLONE_NEWPID | CLONE_NEWCGROUP)))
                return 0;

        user_ns = new_cred ? new_cred->user_ns : current_user_ns();
        if (!ns_capable(user_ns, CAP_SYS_ADMIN))
                return -EPERM;

        *new_nsp = create_new_namespaces(unshare_flags, current, user_ns,
                                         new_fs ? new_fs : current->fs);
        if (IS_ERR(*new_nsp)) {
                err = PTR_ERR(*new_nsp);
                goto out;
        }

out:
        return err;
}

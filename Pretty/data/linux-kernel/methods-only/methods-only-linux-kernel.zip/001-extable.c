/* Given an address, look for it in the exception tables. */
const struct exception_table_entry *search_exception_tables(unsigned long addr)
{
        const struct exception_table_entry *e;

        e = search_extable(__start___ex_table, __stop___ex_table-1, addr);
        if (!e)
                e = search_module_extables(addr);
        return e;
}

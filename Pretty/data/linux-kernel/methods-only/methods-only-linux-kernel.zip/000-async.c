static async_cookie_t lowest_in_progress(struct async_domain *domain)
{
        struct list_head *pending;
        async_cookie_t ret = ASYNC_COOKIE_MAX;
        unsigned long flags;

        spin_lock_irqsave(&async_lock, flags);

        if (domain)
                pending = &domain->pending;
        else
                pending = &async_global_pending;

        if (!list_empty(pending))
                ret = list_first_entry(pending, struct async_entry,
                                       domain_list)->cookie;

        spin_unlock_irqrestore(&async_lock, flags);
        return ret;
}

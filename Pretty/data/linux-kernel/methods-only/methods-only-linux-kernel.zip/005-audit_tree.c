void audit_put_chunk(struct audit_chunk *chunk)
{
        if (atomic_long_dec_and_test(&chunk->refs))
                free_chunk(chunk);
}

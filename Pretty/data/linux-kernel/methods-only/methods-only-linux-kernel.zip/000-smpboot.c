struct task_struct *idle_thread_get(unsigned int cpu)
{
        struct task_struct *tsk = per_cpu(idle_threads, cpu);

        if (!tsk)
                return ERR_PTR(-ENOMEM);
        init_idle(tsk, cpu);
        return tsk;
}

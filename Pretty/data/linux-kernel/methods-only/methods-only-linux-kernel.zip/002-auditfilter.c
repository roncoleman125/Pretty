void audit_free_rule_rcu(struct rcu_head *head)
{
        struct audit_entry *e = container_of(head, struct audit_entry, rcu);
        audit_free_rule(e);
}

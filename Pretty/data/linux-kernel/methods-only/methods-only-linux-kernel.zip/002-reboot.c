/**
 *      register_reboot_notifier - Register function to be called at reboot time
 *      @nb: Info about notifier function to be called
 *
 *      Registers a function with the list of functions
 *      to be called at reboot time.
 *
 *      Currently always returns zero, as blocking_notifier_chain_register()
 *      always returns zero.
 */
int register_reboot_notifier(struct notifier_block *nb)
{
        return blocking_notifier_chain_register(&reboot_notifier_list, nb);
}

static void umh_complete(struct subprocess_info *sub_info)
{
        struct completion *comp = xchg(&sub_info->complete, NULL);
        /*
         * See call_usermodehelper_exec(). If xchg() returns NULL
         * we own sub_info, the UMH_KILLABLE caller has gone away
         * or the caller used UMH_NO_WAIT.
         */
        if (comp)
                complete(comp);
        else
                call_usermodehelper_freeinfo(sub_info);
}

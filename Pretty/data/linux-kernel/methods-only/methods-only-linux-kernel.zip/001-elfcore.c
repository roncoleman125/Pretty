int __weak elf_core_write_extra_phdrs(struct coredump_params *cprm, loff_t offset)
{
        return 1;
}

void release_task(struct task_struct *p)
{
        struct task_struct *leader;
        int zap_leader;
repeat:
        /* don't need to get the RCU readlock here - the process is dead and
         * can't be modifying its own credentials. But shut RCU-lockdep up */
        rcu_read_lock();
        atomic_dec(&__task_cred(p)->user->processes);
        rcu_read_unlock();

        proc_flush_task(p);

        write_lock_irq(&tasklist_lock);
        ptrace_release_task(p);
        __exit_signal(p);

        /*
         * If we are the last non-leader member of the thread
         * group, and the leader is zombie, then notify the
         * group leader's parent process. (if it wants notification.)
         */
        zap_leader = 0;
        leader = p->group_leader;
        if (leader != p && thread_group_empty(leader)
                        && leader->exit_state == EXIT_ZOMBIE) {
                /*
                 * If we were the last child thread and the leader has
                 * exited already, and the leader's parent ignores SIGCHLD,
                 * then we are the one who should release the leader.
                 */
                zap_leader = do_notify_parent(leader, leader->exit_signal);
                if (zap_leader)
                        leader->exit_state = EXIT_DEAD;
        }

        write_unlock_irq(&tasklist_lock);
        release_thread(p);
        call_rcu(&p->rcu, delayed_put_task_struct);

        p = leader;
        if (unlikely(zap_leader))
                goto repeat;
}

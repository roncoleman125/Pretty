void profile_task_exit(struct task_struct *task)
{
        blocking_notifier_call_chain(&task_exit_notifier, 0, task);
}

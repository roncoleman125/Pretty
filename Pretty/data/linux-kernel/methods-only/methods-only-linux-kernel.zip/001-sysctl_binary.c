static ssize_t bin_string(struct file *file,
        void __user *oldval, size_t oldlen, void __user *newval, size_t newlen)
{
        ssize_t result, copied = 0;

        if (oldval && oldlen) {
                char __user *lastp;
                loff_t pos = 0;
                int ch;

                result = vfs_read(file, oldval, oldlen, &pos);
                if (result < 0)
                        goto out;

                copied = result;
                lastp = oldval + copied - 1;

                result = -EFAULT;
                if (get_user(ch, lastp))
                        goto out;

                /* Trim off the trailing newline */
                if (ch == '\n') {
                        result = -EFAULT;
                        if (put_user('\0', lastp))
                                goto out;
                        copied -= 1;
                }
        }

        if (newval && newlen) {
                loff_t pos = 0;

                result = vfs_write(file, newval, newlen, &pos);
                if (result < 0)
                        goto out;
        }

        result = copied;
out:
        return result;
}

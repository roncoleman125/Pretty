static inline void check_kparam_locked(struct module *mod)
{
        BUG_ON(!mutex_is_locked(KPARAM_MUTEX(mod)));
}

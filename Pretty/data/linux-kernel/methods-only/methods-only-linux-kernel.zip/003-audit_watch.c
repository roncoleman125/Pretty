static void audit_put_parent(struct audit_parent *parent)
{
        if (likely(parent))
                fsnotify_put_mark(&parent->mark);
}

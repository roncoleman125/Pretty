static int slots_per_page(struct kprobe_insn_cache *c)
{
        return PAGE_SIZE/(c->insn_size * sizeof(kprobe_opcode_t));
}

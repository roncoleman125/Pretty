static void cpu_stop_init_done(struct cpu_stop_done *done, unsigned int nr_todo)
{
        memset(done, 0, sizeof(*done));
        atomic_set(&done->nr_todo, nr_todo);
        init_completion(&done->completion);
}

static void *get_uts(struct ctl_table *table, int write)
{
        char *which = table->data;
        struct uts_namespace *uts_ns;

        uts_ns = current->nsproxy->uts_ns;
        which = (which - (char *)&init_uts_ns) + (char *)uts_ns;

        if (!write)
                down_read(&uts_sem);
        else
                down_write(&uts_sem);
        return which;
}

static struct resource *next_resource(struct resource *p, bool sibling_only)
{
        /* Caller wants to traverse through siblings only */
        if (sibling_only)
                return p->sibling;

        if (p->child)
                return p->child;
        while (!p->sibling && p->parent)
                p = p->parent;
        return p->sibling;
}

/*
 * Copy task tsk's utsname namespace, or clone it if flags
 * specifies CLONE_NEWUTS.  In latter case, changes to the
 * utsname of this process won't be seen by parent, and vice
 * versa.
 */
struct uts_namespace *copy_utsname(unsigned long flags,
        struct user_namespace *user_ns, struct uts_namespace *old_ns)
{
        struct uts_namespace *new_ns;

        BUG_ON(!old_ns);
        get_uts_ns(old_ns);

        if (!(flags & CLONE_NEWUTS))
                return old_ns;

        new_ns = clone_uts_ns(user_ns, old_ns);

        put_uts_ns(old_ns);
        return new_ns;
}

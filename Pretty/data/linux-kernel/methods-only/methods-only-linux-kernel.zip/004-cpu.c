void put_online_cpus(void)
{
        int refcount;

        if (cpu_hotplug.active_writer == current)
                return;

        refcount = atomic_dec_return(&cpu_hotplug.refcount);
        if (WARN_ON(refcount < 0)) /* try to fix things up */
                atomic_inc(&cpu_hotplug.refcount);

        if (refcount <= 0 && waitqueue_active(&cpu_hotplug.wq))
                wake_up(&cpu_hotplug.wq);

        cpuhp_lock_release();

}

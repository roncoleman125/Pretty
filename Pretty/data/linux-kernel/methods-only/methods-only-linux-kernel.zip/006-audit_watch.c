void audit_put_watch(struct audit_watch *watch)
{
        if (atomic_dec_and_test(&watch->count)) {
                WARN_ON(watch->parent);
                WARN_ON(!list_empty(&watch->rules));
                kfree(watch->path);
                kfree(watch);
        }
}

/*
 * creates the kmem cache to allocate pids from.
 * @nr_ids: the number of numerical ids this pid will have to carry
 */

static struct kmem_cache *create_pid_cachep(int nr_ids)
{
        struct pid_cache *pcache;
        struct kmem_cache *cachep;

        mutex_lock(&pid_caches_mutex);
        list_for_each_entry(pcache, &pid_caches_lh, list)
                if (pcache->nr_ids == nr_ids)
                        goto out;

        pcache = kmalloc(sizeof(struct pid_cache), GFP_KERNEL);
        if (pcache == NULL)
                goto err_alloc;

        snprintf(pcache->name, sizeof(pcache->name), "pid_%d", nr_ids);
        cachep = kmem_cache_create(pcache->name,
                        sizeof(struct pid) + (nr_ids - 1) * sizeof(struct upid),
                        0, SLAB_HWCACHE_ALIGN, NULL);
        if (cachep == NULL)
                goto err_cachep;

        pcache->nr_ids = nr_ids;
        pcache->cachep = cachep;
        list_add(&pcache->list, &pid_caches_lh);
out:
        mutex_unlock(&pid_caches_mutex);
        return pcache->cachep;

err_cachep:
        kfree(pcache);
err_alloc:
        mutex_unlock(&pid_caches_mutex);
        return NULL;
}

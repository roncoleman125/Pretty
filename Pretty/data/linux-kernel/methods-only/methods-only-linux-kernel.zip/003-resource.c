static void *r_start(struct seq_file *m, loff_t *pos)
        __acquires(resource_lock)
{
        struct resource *p = m->private;
        loff_t l = 0;
        read_lock(&resource_lock);
        for (p = p->child; p && l < *pos; p = r_next(m, p, &l))
                ;
        return p;
}

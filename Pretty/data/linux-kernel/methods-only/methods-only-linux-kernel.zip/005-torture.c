/*
 * Crude but fast random-number generator.  Uses a linear congruential
 * generator, with occasional help from cpu_clock().
 */
unsigned long
torture_random(struct torture_random_state *trsp)
{
        if (--trsp->trs_count < 0) {
                trsp->trs_state += (unsigned long)local_clock();
                trsp->trs_count = TORTURE_RANDOM_REFRESH;
        }
        trsp->trs_state = trsp->trs_state * TORTURE_RANDOM_MULT +
                TORTURE_RANDOM_ADD;
        return swahw32(trsp->trs_state);
}

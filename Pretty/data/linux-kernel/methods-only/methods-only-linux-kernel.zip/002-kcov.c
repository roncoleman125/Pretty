static void kcov_put(struct kcov *kcov)
{
        if (atomic_dec_and_test(&kcov->refcount)) {
                vfree(kcov->area);
                kfree(kcov);
        }
}

static struct kthread *to_live_kthread(struct task_struct *k)
{
        struct completion *vfork = ACCESS_ONCE(k->vfork_done);
        if (likely(vfork))
                return __to_kthread(vfork);
        return NULL;
}

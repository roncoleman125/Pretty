/* Initialize an audit filterlist entry. */
static inline struct audit_entry *audit_init_entry(u32 field_count)
{
        struct audit_entry *entry;
        struct audit_field *fields;

        entry = kzalloc(sizeof(*entry), GFP_KERNEL);
        if (unlikely(!entry))
                return NULL;

        fields = kcalloc(field_count, sizeof(*fields), GFP_KERNEL);
        if (unlikely(!fields)) {
                kfree(entry);
                return NULL;
        }
        entry->rule.fields = fields;

        return entry;
}

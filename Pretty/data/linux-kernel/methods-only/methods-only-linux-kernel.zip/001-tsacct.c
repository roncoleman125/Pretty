/*
 * fill in extended accounting fields
 */
void xacct_add_tsk(struct taskstats *stats, struct task_struct *p)
{
        struct mm_struct *mm;

        /* convert pages-nsec/1024 to Mbyte-usec, see __acct_update_integrals */
        stats->coremem = p->acct_rss_mem1 * PAGE_SIZE;
        do_div(stats->coremem, 1000 * KB);
        stats->virtmem = p->acct_vm_mem1 * PAGE_SIZE;
        do_div(stats->virtmem, 1000 * KB);
        mm = get_task_mm(p);
        if (mm) {
                /* adjust to KB unit */
                stats->hiwater_rss   = get_mm_hiwater_rss(mm) * PAGE_SIZE / KB;
                stats->hiwater_vm    = get_mm_hiwater_vm(mm)  * PAGE_SIZE / KB;
                mmput(mm);
        }
        stats->read_char        = p->ioac.rchar & KB_MASK;
        stats->write_char       = p->ioac.wchar & KB_MASK;
        stats->read_syscalls    = p->ioac.syscr & KB_MASK;
        stats->write_syscalls   = p->ioac.syscw & KB_MASK;
//#ifdef CONFIG_TASK_IO_ACCOUNTING
        stats->read_bytes       = p->ioac.read_bytes & KB_MASK;
        stats->write_bytes      = p->ioac.write_bytes & KB_MASK;
        stats->cancelled_write_bytes = p->ioac.cancelled_write_bytes & KB_MASK;
//#else
        stats->read_bytes       = 0;
        stats->write_bytes      = 0;
        stats->cancelled_write_bytes = 0;
//#endif
}

/**
 * pids_uncharge - hierarchically uncharge the pid count
 * @pids: the pid cgroup state
 * @num: the number of pids to uncharge
 */
static void pids_uncharge(struct pids_cgroup *pids, int num)
{
        struct pids_cgroup *p;

        for (p = pids; parent_pids(p); p = parent_pids(p))
                pids_cancel(p, num);
}

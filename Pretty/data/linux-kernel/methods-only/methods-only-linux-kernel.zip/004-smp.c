static __always_inline void csd_unlock(struct call_single_data *csd)
{
        WARN_ON(!(csd->flags & CSD_FLAG_LOCK));

        /*
         * ensure we're all done before releasing data:
         */
        smp_store_release(&csd->flags, 0);
}

SYSCALL_DEFINE2(setregid16, old_gid_t, rgid, old_gid_t, egid)
{
        return sys_setregid(low2highgid(rgid), low2highgid(egid));
}

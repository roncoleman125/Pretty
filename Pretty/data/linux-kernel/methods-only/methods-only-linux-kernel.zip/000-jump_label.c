void jump_label_lock(void)
{
        mutex_lock(&jump_label_mutex);
}

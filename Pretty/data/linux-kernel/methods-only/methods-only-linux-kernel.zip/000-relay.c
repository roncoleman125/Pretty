/*
 * close() vm_op implementation for relay file mapping.
 */
static void relay_file_mmap_close(struct vm_area_struct *vma)
{
        struct rchan_buf *buf = vma->vm_private_data;
        buf->chan->cb->buf_unmapped(buf, vma->vm_file);
}

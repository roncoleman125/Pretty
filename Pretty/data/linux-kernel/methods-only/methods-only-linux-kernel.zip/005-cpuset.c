/* convenient tests for these bits */
static inline bool is_cpuset_online(const struct cpuset *cs)
{
        return test_bit(CS_ONLINE, &cs->flags);
}

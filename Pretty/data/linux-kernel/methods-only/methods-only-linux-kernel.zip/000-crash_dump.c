/*
 * elfcorehdr= specifies the location of elf core header stored by the crashed
 * kernel. This option will be passed by kexec loader to the capture kernel.
 *
 * Syntax: elfcorehdr=[size[KMG]@]offset[KMG]
 */
static int __init setup_elfcorehdr(char *arg)
{
        char *end;
        if (!arg)
                return -EINVAL;
        elfcorehdr_addr = memparse(arg, &end);
        if (*end == '@') {
                elfcorehdr_size = elfcorehdr_addr;
                elfcorehdr_addr = memparse(end + 1, &end);
        }
        return end > arg ? 0 : -EINVAL;
}
early_param("elfcorehdr", setup_elfcorehdr);

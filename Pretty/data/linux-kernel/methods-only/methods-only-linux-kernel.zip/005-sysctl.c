static size_t proc_skip_spaces(char **buf)
{
        size_t ret;
        char *tmp = skip_spaces(*buf);
        ret = tmp - *buf;
        *buf = tmp;
        return ret;
}

/* Apply relocations of type REL */
int __weak
arch_kexec_apply_relocations(const Elf_Ehdr *ehdr, Elf_Shdr *sechdrs,
                             unsigned int relsec)
{
        pr_err("REL relocation unsupported.\n");
        return -ENOEXEC;
}

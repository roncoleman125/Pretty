/**
 * cpu_pm_unregister_notifier - unregister a driver with cpu_pm
 * @nb: notifier block to be unregistered
 *
 * Remove a driver from the CPU PM notifier list.
 *
 * This function may sleep, and has the same return conditions as
 * raw_notifier_chain_unregister.
 */
int cpu_pm_unregister_notifier(struct notifier_block *nb)
{
        unsigned long flags;
        int ret;

        write_lock_irqsave(&cpu_pm_notifier_lock, flags);
        ret = raw_notifier_chain_unregister(&cpu_pm_notifier_chain, nb);
        write_unlock_irqrestore(&cpu_pm_notifier_lock, flags);

        return ret;
}

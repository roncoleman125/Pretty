static void audit_set_portid(struct audit_buffer *ab, __u32 portid)
{
        if (ab) {
                struct nlmsghdr *nlh = nlmsg_hdr(ab->skb);
                nlh->nlmsg_pid = portid;
        }
}

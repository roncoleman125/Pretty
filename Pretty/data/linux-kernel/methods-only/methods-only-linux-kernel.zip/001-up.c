int smp_call_function_single_async(int cpu, struct call_single_data *csd)
{
        unsigned long flags;

        local_irq_save(flags);
        csd->func(csd->info);
        local_irq_restore(flags);
        return 0;
}

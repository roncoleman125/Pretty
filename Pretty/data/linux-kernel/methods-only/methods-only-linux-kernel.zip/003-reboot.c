/**
 *      unregister_reboot_notifier - Unregister previously registered reboot notifier
 *      @nb: Hook to be unregistered
 *
 *      Unregisters a previously registered reboot
 *      notifier function.
 *
 *      Returns zero on success, or %-ENOENT on failure.
 */
int unregister_reboot_notifier(struct notifier_block *nb)
{
        return blocking_notifier_chain_unregister(&reboot_notifier_list, nb);
}

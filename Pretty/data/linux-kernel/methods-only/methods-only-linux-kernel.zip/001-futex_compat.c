static void __user *futex_uaddr(struct robust_list __user *entry,
                                compat_long_t futex_offset)
{
        compat_uptr_t base = ptr_to_compat(entry);
        void __user *uaddr = compat_ptr(base + futex_offset);

        return uaddr;
}

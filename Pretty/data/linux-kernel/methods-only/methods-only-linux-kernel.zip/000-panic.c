static long no_blink(int state)
{
        return 0;
}

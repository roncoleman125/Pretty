static int jump_label_cmp(const void *a, const void *b)
{
        const struct jump_entry *jea = a;
        const struct jump_entry *jeb = b;

        if (jea->key < jeb->key)
                return -1;

        if (jea->key > jeb->key)
                return 1;

        return 0;
}

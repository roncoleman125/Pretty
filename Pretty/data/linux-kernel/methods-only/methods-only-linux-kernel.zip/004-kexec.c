COMPAT_SYSCALL_DEFINE4(kexec_load, compat_ulong_t, entry,
                       compat_ulong_t, nr_segments,
                       struct compat_kexec_segment __user *, segments,
                       compat_ulong_t, flags)
{
        struct compat_kexec_segment in;
        struct kexec_segment out, __user *ksegments;
        unsigned long i, result;

        /* Don't allow clients that don't understand the native
         * architecture to do anything.
         */
        if ((flags & KEXEC_ARCH_MASK) == KEXEC_ARCH_DEFAULT)
                return -EINVAL;

        if (nr_segments > KEXEC_SEGMENT_MAX)
                return -EINVAL;

        ksegments = compat_alloc_user_space(nr_segments * sizeof(out));
        for (i = 0; i < nr_segments; i++) {
                result = copy_from_user(&in, &segments[i], sizeof(in));
                if (result)
                        return -EFAULT;

                out.buf   = compat_ptr(in.buf);
                out.bufsz = in.bufsz;
                out.mem   = in.mem;
                out.memsz = in.memsz;

                result = copy_to_user(&ksegments[i], &out, sizeof(out));
                if (result)
                        return -EFAULT;
        }

        return sys_kexec_load(entry, nr_segments, ksegments, flags);
}
//#endif

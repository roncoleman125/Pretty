static void audit_fsnotify_mark_free(struct audit_fsnotify_mark *audit_mark)
{
        kfree(audit_mark->path);
        kfree(audit_mark);
}

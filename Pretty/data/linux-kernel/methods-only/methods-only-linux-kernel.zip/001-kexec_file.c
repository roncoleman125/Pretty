void * __weak arch_kexec_kernel_image_load(struct kimage *image)
{
        return ERR_PTR(-ENOEXEC);
}

static int audit_set_rate_limit(u32 limit)
{
        return audit_do_config_change("audit_rate_limit", &audit_rate_limit, limit);
}

static void cgroup_idr_remove(struct idr *idr, int id)
{
        spin_lock_bh(&cgroup_idr_lock);
        idr_remove(idr, id);
        spin_unlock_bh(&cgroup_idr_lock);
}

/**
 * acct_account_cputime - update mm integral after cputime update
 * @tsk: task_struct for accounting
 */
void acct_account_cputime(struct task_struct *tsk)
{
        __acct_update_integrals(tsk, tsk->utime, tsk->stime);
}

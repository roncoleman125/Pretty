/*
 * Clean up a task's credentials when it exits
 */
void exit_creds(struct task_struct *tsk)
{
        struct cred *cred;

        kdebug("exit_creds(%u,%p,%p,{%d,%d})", tsk->pid, tsk->real_cred, tsk->cred,
               atomic_read(&tsk->cred->usage),
               read_cred_subscribers(tsk->cred));

        cred = (struct cred *) tsk->real_cred;
        tsk->real_cred = NULL;
        validate_creds(cred);
        alter_cred_subscribers(cred, -1);
        put_cred(cred);

        cred = (struct cred *) tsk->cred;
        tsk->cred = NULL;
        validate_creds(cred);
        alter_cred_subscribers(cred, -1);
        put_cred(cred);
}

static int kp_pre_handler2(struct kprobe *p, struct pt_regs *regs)
{
        preh_val = (rand1 / div_factor) + 1;
        return 0;
}

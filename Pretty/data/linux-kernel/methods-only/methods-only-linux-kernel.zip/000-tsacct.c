/*
 * fill in basic accounting fields
 */
void bacct_add_tsk(struct user_namespace *user_ns,
                   struct pid_namespace *pid_ns,
                   struct taskstats *stats, struct task_struct *tsk)
{
        const struct cred *tcred;
        cputime_t utime, stime, utimescaled, stimescaled;
        u64 delta;

        BUILD_BUG_ON(TS_COMM_LEN < TASK_COMM_LEN);

        /* calculate task elapsed time in nsec */
        delta = ktime_get_ns() - tsk->start_time;
        /* Convert to micro seconds */
        do_div(delta, NSEC_PER_USEC);
        stats->ac_etime = delta;
        /* Convert to seconds for btime */
        do_div(delta, USEC_PER_SEC);
        stats->ac_btime = get_seconds() - delta;
        if (thread_group_leader(tsk)) {
                stats->ac_exitcode = tsk->exit_code;
                if (tsk->flags & PF_FORKNOEXEC)
                        stats->ac_flag |= AFORK;
        }
        if (tsk->flags & PF_SUPERPRIV)
                stats->ac_flag |= ASU;
        if (tsk->flags & PF_DUMPCORE)
                stats->ac_flag |= ACORE;
        if (tsk->flags & PF_SIGNALED)
                stats->ac_flag |= AXSIG;
        stats->ac_nice   = task_nice(tsk);
        stats->ac_sched  = tsk->policy;
        stats->ac_pid    = task_pid_nr_ns(tsk, pid_ns);
        rcu_read_lock();
        tcred = __task_cred(tsk);
        stats->ac_uid    = from_kuid_munged(user_ns, tcred->uid);
        stats->ac_gid    = from_kgid_munged(user_ns, tcred->gid);
        stats->ac_ppid   = pid_alive(tsk) ?
                task_tgid_nr_ns(rcu_dereference(tsk->real_parent), pid_ns) : 0;
        rcu_read_unlock();

        task_cputime(tsk, &utime, &stime);
        stats->ac_utime = cputime_to_usecs(utime);
        stats->ac_stime = cputime_to_usecs(stime);

        task_cputime_scaled(tsk, &utimescaled, &stimescaled);
        stats->ac_utimescaled = cputime_to_usecs(utimescaled);
        stats->ac_stimescaled = cputime_to_usecs(stimescaled);

        stats->ac_minflt = tsk->min_flt;
        stats->ac_majflt = tsk->maj_flt;

        strncpy(stats->ac_comm, tsk->comm, sizeof(stats->ac_comm));
}

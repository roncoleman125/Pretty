static raw_spinlock_t *kretprobe_table_lock_ptr(unsigned long hash)
{
        return &(kretprobe_table_locks[hash].lock);
}

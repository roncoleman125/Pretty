static void uid_hash_remove(struct user_struct *up)
{
        hlist_del_init(&up->uidhash_node);
}

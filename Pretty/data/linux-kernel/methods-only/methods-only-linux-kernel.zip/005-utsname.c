static struct ns_common *utsns_get(struct task_struct *task)
{
        struct uts_namespace *ns = NULL;
        struct nsproxy *nsproxy;

        task_lock(task);
        nsproxy = task->nsproxy;
        if (nsproxy) {
                ns = nsproxy->uts_ns;
                get_uts_ns(ns);
        }
        task_unlock(task);

        return ns ? &ns->ns : NULL;
}

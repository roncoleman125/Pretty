static inline struct freezer *css_freezer(struct cgroup_subsys_state *css)
{
        return css ? container_of(css, struct freezer, css) : NULL;
}

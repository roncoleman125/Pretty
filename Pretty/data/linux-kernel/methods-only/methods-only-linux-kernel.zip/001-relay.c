/*
 * fault() vm_op implementation for relay file mapping.
 */
static int relay_buf_fault(struct vm_area_struct *vma, struct vm_fault *vmf)
{
        struct page *page;
        struct rchan_buf *buf = vma->vm_private_data;
        pgoff_t pgoff = vmf->pgoff;

        if (!buf)
                return VM_FAULT_OOM;

        page = vmalloc_to_page(buf->start + (pgoff << PAGE_SHIFT));
        if (!page)
                return VM_FAULT_SIGBUS;
        get_page(page);
        vmf->page = page;

        return 0;
}

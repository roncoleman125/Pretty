static void audit_update_mark(struct audit_fsnotify_mark *audit_mark,
                             struct inode *inode)
{
        audit_mark->dev = inode ? inode->i_sb->s_dev : AUDIT_DEV_UNSET;
        audit_mark->ino = inode ? inode->i_ino : AUDIT_INO_UNSET;
}

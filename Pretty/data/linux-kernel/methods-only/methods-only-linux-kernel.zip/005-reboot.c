/**
 *      unregister_restart_handler - Unregister previously registered
 *                                   restart handler
 *      @nb: Hook to be unregistered
 *
 *      Unregisters a previously registered restart handler function.
 *
 *      Returns zero on success, or %-ENOENT on failure.
 */
int unregister_restart_handler(struct notifier_block *nb)
{
        return atomic_notifier_chain_unregister(&restart_handler_list, nb);
}

void __delayacct_blkio_end(void)
{
        if (current->delays->flags & DELAYACCT_PF_SWAPIN)
                /* Swapin block I/O */
                delayacct_end(&current->delays->blkio_start,
                        &current->delays->swapin_delay,
                        &current->delays->swapin_count);
        else    /* Other block I/O */
                delayacct_end(&current->delays->blkio_start,
                        &current->delays->blkio_delay,
                        &current->delays->blkio_count);
}

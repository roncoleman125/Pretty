static struct pids_cgroup *parent_pids(struct pids_cgroup *pids)
{
        return css_pids(pids->css.parent);
}

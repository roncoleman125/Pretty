static inline bool seccomp_may_assign_mode(unsigned long seccomp_mode)
{
        assert_spin_locked(&current->sighand->siglock);

        if (current->seccomp.mode && current->seccomp.mode != seccomp_mode)
                return false;

        return true;
}

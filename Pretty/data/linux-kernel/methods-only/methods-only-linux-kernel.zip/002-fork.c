void __weak arch_release_task_struct(struct task_struct *tsk)
{
}

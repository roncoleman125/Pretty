/* uevent helper program, used during early boot */
static ssize_t uevent_helper_show(struct kobject *kobj,
                                  struct kobj_attribute *attr, char *buf)
{
        return sprintf(buf, "%s\n", uevent_helper);
}

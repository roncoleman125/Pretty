static inline struct bsd_acct_struct *to_acct(struct fs_pin *p)
{
        return p ? container_of(p, struct bsd_acct_struct, pin) : NULL;
}

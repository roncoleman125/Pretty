static long kptr_obfuscate(long v, int type)
{
        return (v ^ cookies[type][0]) * cookies[type][1];
}

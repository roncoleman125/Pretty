static void kcmp_unlock(struct mutex *m1, struct mutex *m2)
{
        if (likely(m2 != m1))
                mutex_unlock(m2);
        mutex_unlock(m1);
}

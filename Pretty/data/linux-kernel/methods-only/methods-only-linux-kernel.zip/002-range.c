void subtract_range(struct range *range, int az, u64 start, u64 end)
{
        int i, j;

        if (start >= end)
                return;

        for (j = 0; j < az; j++) {
                if (!range[j].end)
                        continue;

                if (start <= range[j].start && end >= range[j].end) {
                        range[j].start = 0;
                        range[j].end = 0;
                        continue;
                }

                if (start <= range[j].start && end < range[j].end &&
                    range[j].start < end) {
                        range[j].start = end;
                        continue;
                }


                if (start > range[j].start && end >= range[j].end &&
                    range[j].end > start) {
                        range[j].end = start;
                        continue;
                }

                if (start > range[j].start && end < range[j].end) {
                        /* Find the new spare: */
                        for (i = 0; i < az; i++) {
                                if (range[i].end == 0)
                                        break;
                        }
                        if (i < az) {
                                range[i].end = range[j].end;
                                range[i].start = end;
                        } else {
                                pr_err("%s: run out of slot in ranges\n",
                                        __func__);
                        }
                        range[j].end = start;
                        continue;
                }
        }
}

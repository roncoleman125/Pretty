/**
 * idle_init - Initialize the idle thread for a cpu
 * @cpu:        The cpu for which the idle thread should be initialized
 *
 * Creates the thread if it does not exist.
 */
static inline void idle_init(unsigned int cpu)
{
        struct task_struct *tsk = per_cpu(idle_threads, cpu);

        if (!tsk) {
                tsk = fork_idle(cpu);
                if (IS_ERR(tsk))
                        pr_err("SMP: fork_idle() failed for CPU %u\n", cpu);
                else
                        per_cpu(idle_threads, cpu) = tsk;
        }
}

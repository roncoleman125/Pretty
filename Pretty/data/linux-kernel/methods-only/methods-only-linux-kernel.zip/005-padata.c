static void padata_reorder(struct parallel_data *pd)
{
        int cb_cpu;
        struct padata_priv *padata;
        struct padata_serial_queue *squeue;
        struct padata_instance *pinst = pd->pinst;

        /*
         * We need to ensure that only one cpu can work on dequeueing of
         * the reorder queue the time. Calculating in which percpu reorder
         * queue the next object will arrive takes some time. A spinlock
         * would be highly contended. Also it is not clear in which order
         * the objects arrive to the reorder queues. So a cpu could wait to
         * get the lock just to notice that there is nothing to do at the
         * moment. Therefore we use a trylock and let the holder of the lock
         * care for all the objects enqueued during the holdtime of the lock.
         */
        if (!spin_trylock_bh(&pd->lock))
                return;

        while (1) {
                padata = padata_get_next(pd);

                /*
                 * All reorder queues are empty, or the next object that needs
                 * serialization is parallel processed by another cpu and is
                 * still on it's way to the cpu's reorder queue, nothing to
                 * do for now.
                 */
                if (!padata || PTR_ERR(padata) == -EINPROGRESS)
                        break;

                /*
                 * This cpu has to do the parallel processing of the next
                 * object. It's waiting in the cpu's parallelization queue,
                 * so exit immediately.
                 */
                if (PTR_ERR(padata) == -ENODATA) {
                        del_timer(&pd->timer);
                        spin_unlock_bh(&pd->lock);
                        return;
                }

                cb_cpu = padata->cb_cpu;
                squeue = per_cpu_ptr(pd->squeue, cb_cpu);

                spin_lock(&squeue->serial.lock);
                list_add_tail(&padata->list, &squeue->serial.list);
                spin_unlock(&squeue->serial.lock);

                queue_work_on(cb_cpu, pinst->wq, &squeue->work);
        }

        spin_unlock_bh(&pd->lock);

        /*
         * The next object that needs serialization might have arrived to
         * the reorder queues in the meantime, we will be called again
         * from the timer function if no one else cares for it.
         */
        if (atomic_read(&pd->reorder_objects)
                        && !(pinst->flags & PADATA_RESET))
                mod_timer(&pd->timer, jiffies + HZ);
        else
                del_timer(&pd->timer);

        return;
}

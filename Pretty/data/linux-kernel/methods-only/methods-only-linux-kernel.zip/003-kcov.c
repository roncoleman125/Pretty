void kcov_task_init(struct task_struct *t)
{
        t->kcov_mode = KCOV_MODE_DISABLED;
        t->kcov_size = 0;
        t->kcov_area = NULL;
        t->kcov = NULL;
}

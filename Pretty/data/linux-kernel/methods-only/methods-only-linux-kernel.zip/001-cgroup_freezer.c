static inline struct freezer *task_freezer(struct task_struct *task)
{
        return css_freezer(task_css(task, freezer_cgrp_id));
}

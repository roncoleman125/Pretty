static ssize_t bin_dir(struct file *file,
        void __user *oldval, size_t oldlen, void __user *newval, size_t newlen)
{
        return -ENOTDIR;
}

int __kernel_text_address(unsigned long addr)
{
        if (core_kernel_text(addr))
                return 1;
        if (is_module_text_address(addr))
                return 1;
        if (is_ftrace_trampoline(addr))
                return 1;
        /*
         * There might be init symbols in saved stacktraces.
         * Give those symbols a chance to be printed in
         * backtraces (such as lockdep traces).
         *
         * Since we are after the module-symbols check, there's
         * no danger of address overlap:
         */
        if (init_kernel_text(addr))
                return 1;
        return 0;
}

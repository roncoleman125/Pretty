static inline void get_tree(struct audit_tree *tree)
{
        atomic_inc(&tree->count);
}

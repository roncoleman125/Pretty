__weak void
save_stack_trace_regs(struct pt_regs *regs, struct stack_trace *trace)
{
        WARN_ONCE(1, KERN_INFO "save_stack_trace_regs() not implemented yet.\n");
}

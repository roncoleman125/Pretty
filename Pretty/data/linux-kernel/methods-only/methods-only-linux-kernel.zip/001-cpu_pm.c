/**
 * cpu_pm_register_notifier - register a driver with cpu_pm
 * @nb: notifier block to register
 *
 * Add a driver to a list of drivers that are notified about
 * CPU and CPU cluster low power entry and exit.
 *
 * This function may sleep, and has the same return conditions as
 * raw_notifier_chain_register.
 */
int cpu_pm_register_notifier(struct notifier_block *nb)
{
        unsigned long flags;
        int ret;

        write_lock_irqsave(&cpu_pm_notifier_lock, flags);
        ret = raw_notifier_chain_register(&cpu_pm_notifier_chain, nb);
        write_unlock_irqrestore(&cpu_pm_notifier_lock, flags);

        return ret;
}

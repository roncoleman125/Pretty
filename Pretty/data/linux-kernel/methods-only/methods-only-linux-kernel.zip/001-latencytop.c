static void clear_global_latency_tracing(void)
{
        unsigned long flags;

        raw_spin_lock_irqsave(&latency_lock, flags);
        memset(&latency_record, 0, sizeof(latency_record));
        raw_spin_unlock_irqrestore(&latency_lock, flags);
}

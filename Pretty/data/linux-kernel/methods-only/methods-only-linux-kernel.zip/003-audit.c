/**
 * audit_log_lost - conditionally log lost audit message event
 * @message: the message stating reason for lost audit message
 *
 * Emit at least 1 message per second, even if audit_rate_check is
 * throttling.
 * Always increment the lost messages counter.
*/
void audit_log_lost(const char *message)
{
        static unsigned long    last_msg = 0;
        static DEFINE_SPINLOCK(lock);
        unsigned long           flags;
        unsigned long           now;
        int                     print;

        atomic_inc(&audit_lost);

        print = (audit_failure == AUDIT_FAIL_PANIC || !audit_rate_limit);

        if (!print) {
                spin_lock_irqsave(&lock, flags);
                now = jiffies;
                if (now - last_msg > HZ) {
                        print = 1;
                        last_msg = now;
                }
                spin_unlock_irqrestore(&lock, flags);
        }

        if (print) {
                if (printk_ratelimit())
                        pr_warn("audit_lost=%u audit_rate_limit=%u audit_backlog_limit=%u\n",
                                atomic_read(&audit_lost),
                                audit_rate_limit,
                                audit_backlog_limit);
                audit_panic(message);
        }
}

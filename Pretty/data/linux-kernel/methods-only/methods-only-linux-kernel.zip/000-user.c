/*
 * These routines must be called with the uidhash spinlock held!
 */
static void uid_hash_insert(struct user_struct *up, struct hlist_head *hashent)
{
        hlist_add_head(&up->uidhash_node, hashent);
}

static int __init delayacct_setup_disable(char *str)
{
        delayacct_on = 0;
        return 1;
}

static int test_kprobe(void)
{
        int ret;

        ret = register_kprobe(&kp);
        if (ret < 0) {
                pr_err("register_kprobe returned %d\n", ret);
                return ret;
        }

        ret = target(rand1);
        unregister_kprobe(&kp);

        if (preh_val == 0) {
                pr_err("kprobe pre_handler not called\n");
                handler_errors++;
        }

        if (posth_val == 0) {
                pr_err("kprobe post_handler not called\n");
                handler_errors++;
        }

        return 0;
}

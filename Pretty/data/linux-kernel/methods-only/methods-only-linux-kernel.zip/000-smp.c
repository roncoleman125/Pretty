static int
hotplug_cfd(struct notifier_block *nfb, unsigned long action, void *hcpu)
{
        long cpu = (long)hcpu;
        struct call_function_data *cfd = &per_cpu(cfd_data, cpu);

        switch (action) {
        case CPU_UP_PREPARE:
        case CPU_UP_PREPARE_FROZEN:
                if (!zalloc_cpumask_var_node(&cfd->cpumask, GFP_KERNEL,
                                cpu_to_node(cpu)))
                        return notifier_from_errno(-ENOMEM);
                cfd->csd = alloc_percpu(struct call_single_data);
                if (!cfd->csd) {
                        free_cpumask_var(cfd->cpumask);
                        return notifier_from_errno(-ENOMEM);
                }
                break;

//#ifdef CONFIG_HOTPLUG_CPU
        case CPU_UP_CANCELED:
        case CPU_UP_CANCELED_FROZEN:
                /* Fall-through to the CPU_DEAD[_FROZEN] case. */

        case CPU_DEAD:
        case CPU_DEAD_FROZEN:
                free_cpumask_var(cfd->cpumask);
                free_percpu(cfd->csd);
                break;

        case CPU_DYING:
        case CPU_DYING_FROZEN:
                /*
                 * The IPIs for the smp-call-function callbacks queued by other
                 * CPUs might arrive late, either due to hardware latencies or
                 * because this CPU disabled interrupts (inside stop-machine)
                 * before the IPIs were sent. So flush out any pending callbacks
                 * explicitly (without waiting for the IPIs to arrive), to
                 * ensure that the outgoing CPU doesn't go offline with work
                 * still pending.
                 */
                flush_smp_call_function_queue(false);
                break;
//#endif
        };

        return NOTIFY_OK;
}

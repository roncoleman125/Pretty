/*
 * free an array of pointers of struct page
 */
static void relay_free_page_array(struct page **array)
{
        kvfree(array);
}

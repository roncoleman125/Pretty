void __thaw_task(struct task_struct *p)
{
        unsigned long flags;

        spin_lock_irqsave(&freezer_lock, flags);
        if (frozen(p))
                wake_up_process(p);
        spin_unlock_irqrestore(&freezer_lock, flags);
}

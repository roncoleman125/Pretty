static int lstats_show(struct seq_file *m, void *v)
{
        int i;

        seq_puts(m, "Latency Top version : v0.1\n");

        for (i = 0; i < MAXLR; i++) {
                struct latency_record *lr = &latency_record[i];

                if (lr->backtrace[0]) {
                        int q;
                        seq_printf(m, "%i %lu %lu",
                                   lr->count, lr->time, lr->max);
                        for (q = 0; q < LT_BACKTRACEDEPTH; q++) {
                                unsigned long bt = lr->backtrace[q];
                                if (!bt)
                                        break;
                                if (bt == ULONG_MAX)
                                        break;
                                seq_printf(m, " %ps", (void *)bt);
                        }
                        seq_puts(m, "\n");
                }
        }
        return 0;
}

static void __exit ikconfig_cleanup(void)
{
        remove_proc_entry("config.gz", NULL);
}

int __ref profile_init(void)
{
        int buffer_bytes;
        if (!prof_on)
                return 0;

        /* only text is profiled */
        prof_len = (_etext - _stext) >> prof_shift;
        buffer_bytes = prof_len*sizeof(atomic_t);

        if (!alloc_cpumask_var(&prof_cpu_mask, GFP_KERNEL))
                return -ENOMEM;

        cpumask_copy(prof_cpu_mask, cpu_possible_mask);

        prof_buffer = kzalloc(buffer_bytes, GFP_KERNEL|__GFP_NOWARN);
        if (prof_buffer)
                return 0;

        prof_buffer = alloc_pages_exact(buffer_bytes,
                                        GFP_KERNEL|__GFP_ZERO|__GFP_NOWARN);
        if (prof_buffer)
                return 0;

        prof_buffer = vzalloc(buffer_bytes);
        if (prof_buffer)
                return 0;

        free_cpumask_var(prof_cpu_mask);
        return -ENOMEM;
}

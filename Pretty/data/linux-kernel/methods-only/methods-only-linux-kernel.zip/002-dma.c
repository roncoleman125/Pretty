int request_dma(unsigned int dmanr, const char *device_id)
{
        return -EINVAL;
}

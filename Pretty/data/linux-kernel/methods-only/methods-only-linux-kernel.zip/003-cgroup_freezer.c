bool cgroup_freezing(struct task_struct *task)
{
        bool ret;

        rcu_read_lock();
        ret = task_freezer(task)->state & CGROUP_FREEZING;
        rcu_read_unlock();

        return ret;
}

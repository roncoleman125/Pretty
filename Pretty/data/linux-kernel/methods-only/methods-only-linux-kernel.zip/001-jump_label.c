void jump_label_unlock(void)
{
        mutex_unlock(&jump_label_mutex);
}

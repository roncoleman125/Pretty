static void __sched
account_global_scheduler_latency(struct task_struct *tsk,
                                 struct latency_record *lat)
{
        int firstnonnull = MAXLR + 1;
        int i;

        if (!latencytop_enabled)
                return;

        /* skip kernel threads for now */
        if (!tsk->mm)
                return;

        for (i = 0; i < MAXLR; i++) {
                int q, same = 1;

                /* Nothing stored: */
                if (!latency_record[i].backtrace[0]) {
                        if (firstnonnull > i)
                                firstnonnull = i;
                        continue;
                }
                for (q = 0; q < LT_BACKTRACEDEPTH; q++) {
                        unsigned long record = lat->backtrace[q];

                        if (latency_record[i].backtrace[q] != record) {
                                same = 0;
                                break;
                        }

                        /* 0 and ULONG_MAX entries mean end of backtrace: */
                        if (record == 0 || record == ULONG_MAX)
                                break;
                }
                if (same) {
                        latency_record[i].count++;
                        latency_record[i].time += lat->time;
                        if (lat->time > latency_record[i].max)
                                latency_record[i].max = lat->time;
                        return;
                }
        }

        i = firstnonnull;
        if (i >= MAXLR - 1)
                return;

        /* Allocted a new one: */
        memcpy(&latency_record[i], lat, sizeof(struct latency_record));
}

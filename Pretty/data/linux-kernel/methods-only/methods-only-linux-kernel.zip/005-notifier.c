/**
 *      atomic_notifier_chain_unregister - Remove notifier from an atomic notifier chain
 *      @nh: Pointer to head of the atomic notifier chain
 *      @n: Entry to remove from notifier chain
 *
 *      Removes a notifier from an atomic notifier chain.
 *
 *      Returns zero on success or %-ENOENT on failure.
 */
int atomic_notifier_chain_unregister(struct atomic_notifier_head *nh,
                struct notifier_block *n)
{
        unsigned long flags;
        int ret;

        spin_lock_irqsave(&nh->lock, flags);
        ret = notifier_chain_unregister(&nh->head, n);
        spin_unlock_irqrestore(&nh->lock, flags);
        synchronize_rcu();
        return ret;
}

/**
 * padata_do_parallel - padata parallelization function
 *
 * @pinst: padata instance
 * @padata: object to be parallelized
 * @cb_cpu: cpu the serialization callback function will run on,
 *          must be in the serial cpumask of padata(i.e. cpumask.cbcpu).
 *
 * The parallelization callback function will run with BHs off.
 * Note: Every object which is parallelized by padata_do_parallel
 * must be seen by padata_do_serial.
 */
int padata_do_parallel(struct padata_instance *pinst,
                       struct padata_priv *padata, int cb_cpu)
{
        int target_cpu, err;
        struct padata_parallel_queue *queue;
        struct parallel_data *pd;

        rcu_read_lock_bh();

        pd = rcu_dereference_bh(pinst->pd);

        err = -EINVAL;
        if (!(pinst->flags & PADATA_INIT) || pinst->flags & PADATA_INVALID)
                goto out;

        if (!cpumask_test_cpu(cb_cpu, pd->cpumask.cbcpu))
                goto out;

        err =  -EBUSY;
        if ((pinst->flags & PADATA_RESET))
                goto out;

        if (atomic_read(&pd->refcnt) >= MAX_OBJ_NUM)
                goto out;

        err = 0;
        atomic_inc(&pd->refcnt);
        padata->pd = pd;
        padata->cb_cpu = cb_cpu;

        target_cpu = padata_cpu_hash(pd);
        queue = per_cpu_ptr(pd->pqueue, target_cpu);

        spin_lock(&queue->parallel.lock);
        list_add_tail(&padata->list, &queue->parallel.list);
        spin_unlock(&queue->parallel.lock);

        queue_work_on(target_cpu, pinst->wq, &queue->work);

out:
        rcu_read_unlock_bh();

        return err;
}

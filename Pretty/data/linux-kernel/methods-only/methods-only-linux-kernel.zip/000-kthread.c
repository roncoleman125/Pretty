static inline struct kthread *to_kthread(struct task_struct *k)
{
        return __to_kthread(k->vfork_done);
}

int __weak arch_kimage_file_post_load_cleanup(struct kimage *image)
{
        return -EINVAL;
}

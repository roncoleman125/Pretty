void clear_all_latency_tracing(struct task_struct *p)
{
        unsigned long flags;

        if (!latencytop_enabled)
                return;

        raw_spin_lock_irqsave(&latency_lock, flags);
        memset(&p->latency_record, 0, sizeof(p->latency_record));
        p->latency_record_count = 0;
        raw_spin_unlock_irqrestore(&latency_lock, flags);
}

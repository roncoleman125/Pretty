static void __cpu_stop_queue_work(struct cpu_stopper *stopper,
                                        struct cpu_stop_work *work)
{
        list_add_tail(&work->list, &stopper->works);
        wake_up_process(stopper->thread);
}

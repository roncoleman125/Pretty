static __always_inline unsigned long __mod_tree_size(struct latch_tree_node *n)
{
        struct module_layout *layout = container_of(n, struct module_layout, mtn.node);

        return (unsigned long)layout->size;
}

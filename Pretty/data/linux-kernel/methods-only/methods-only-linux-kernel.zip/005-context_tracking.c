/**
 * context_tracking_exit - Inform the context tracking that the CPU is
 *                         exiting user or guest mode and entering the kernel.
 *
 * This function must be called after we entered the kernel from user or
 * guest space before any use of RCU read side critical section. This
 * potentially include any high level kernel code like syscalls, exceptions,
 * signal handling, etc...
 *
 * This call supports re-entrancy. This way it can be called from any exception
 * handler without needing to know if we came from userspace or not.
 */
void __context_tracking_exit(enum ctx_state state)
{
        if (!context_tracking_recursion_enter())
                return;

        if (__this_cpu_read(context_tracking.state) == state) {
                if (__this_cpu_read(context_tracking.active)) {
                        /*
                         * We are going to run code that may use RCU. Inform
                         * RCU core about that (ie: we may need the tick again).
                         */
                        rcu_user_exit();
                        if (state == CONTEXT_USER) {
                                vtime_user_exit(current);
                                trace_user_exit(0);
                        }
                }
                __this_cpu_write(context_tracking.state, CONTEXT_KERNEL);
        }
        context_tracking_recursion_exit();
}

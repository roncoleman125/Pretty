static int backtrace_regression_test(void)
{
        pr_info("====[ backtrace testing ]===========\n");

        backtrace_test_normal();
        backtrace_test_irq();
        backtrace_test_saved();

        pr_info("====[ end of backtrace testing ]====\n");
        return 0;
}

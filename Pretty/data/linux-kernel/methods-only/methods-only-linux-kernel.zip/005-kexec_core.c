static void kimage_free_pages(struct page *page)
{
        unsigned int order, count, i;

        order = page_private(page);
        count = 1 << order;
        for (i = 0; i < count; i++)
                ClearPageReserved(page + i);
        __free_pages(page, order);
}

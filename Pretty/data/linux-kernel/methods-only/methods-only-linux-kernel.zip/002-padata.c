static void padata_parallel_worker(struct work_struct *parallel_work)
{
        struct padata_parallel_queue *pqueue;
        struct parallel_data *pd;
        struct padata_instance *pinst;
        LIST_HEAD(local_list);

        local_bh_disable();
        pqueue = container_of(parallel_work,
                              struct padata_parallel_queue, work);
        pd = pqueue->pd;
        pinst = pd->pinst;

        spin_lock(&pqueue->parallel.lock);
        list_replace_init(&pqueue->parallel.list, &local_list);
        spin_unlock(&pqueue->parallel.lock);

        while (!list_empty(&local_list)) {
                struct padata_priv *padata;

                padata = list_entry(local_list.next,
                                    struct padata_priv, list);

                list_del_init(&padata->list);

                padata->parallel(padata);
        }

        local_bh_enable();
}

/* fill a group_info from a user-space array - it must be allocated already */
static int groups_from_user(struct group_info *group_info,
    gid_t __user *grouplist)
{
        struct user_namespace *user_ns = current_user_ns();
        int i;
        unsigned int count = group_info->ngroups;

        for (i = 0; i < count; i++) {
                gid_t gid;
                kgid_t kgid;
                if (get_user(gid, grouplist+i))
                        return -EFAULT;

                kgid = make_kgid(user_ns, gid);
                if (!gid_valid(kgid))
                        return -EINVAL;

                GROUP_AT(group_info, i) = kgid;
        }
        return 0;
}

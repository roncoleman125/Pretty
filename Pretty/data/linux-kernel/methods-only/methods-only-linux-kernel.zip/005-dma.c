static int proc_dma_show(struct seq_file *m, void *v)
{
        seq_puts(m, "No DMA\n");
        return 0;
}

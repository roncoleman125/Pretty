static int
hung_task_panic(struct notifier_block *this, unsigned long event, void *ptr)
{
        did_panic = 1;

        return NOTIFY_DONE;
}

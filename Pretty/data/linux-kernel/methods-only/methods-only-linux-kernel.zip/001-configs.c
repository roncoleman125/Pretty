static int __init ikconfig_init(void)
{
        struct proc_dir_entry *entry;

        /* create the current config file */
        entry = proc_create("config.gz", S_IFREG | S_IRUGO, NULL,
                            &ikconfig_file_ops);
        if (!entry)
                return -ENOMEM;

        proc_set_size(entry, kernel_config_data_size);

        return 0;
}

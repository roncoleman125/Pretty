/* constraints to be met while allocating resources */
struct resource_constraint {
        resource_size_t min, max, align;
        resource_size_t (*alignf)(void *, const struct resource *,
                        resource_size_t, resource_size_t);
        void *alignf_data;
};

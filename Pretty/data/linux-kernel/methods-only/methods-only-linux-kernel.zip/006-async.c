/**
 * async_unregister_domain - ensure no more anonymous waiters on this domain
 * @domain: idle domain to flush out of any async_synchronize_full instances
 *
 * async_synchronize_{cookie|full}_domain() are not flushed since callers
 * of these routines should know the lifetime of @domain
 *
 * Prefer ASYNC_DOMAIN_EXCLUSIVE() declarations over flushing
 */
void async_unregister_domain(struct async_domain *domain)
{
        spin_lock_irq(&async_lock);
        WARN_ON(!domain->registered || !list_empty(&domain->pending));
        domain->registered = 0;
        spin_unlock_irq(&async_lock);
}

static void debug_print_probes(struct tracepoint_func *funcs)
{
        int i;

        if (!tracepoint_debug || !funcs)
                return;

        for (i = 0; funcs[i].func; i++)
                printk(KERN_DEBUG "Probe %d : %p\n", i, funcs[i].func);
}

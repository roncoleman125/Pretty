static struct uts_namespace *create_uts_ns(void)
{
        struct uts_namespace *uts_ns;

        uts_ns = kmalloc(sizeof(struct uts_namespace), GFP_KERNEL);
        if (uts_ns)
                kref_init(&uts_ns->kref);
        return uts_ns;
}

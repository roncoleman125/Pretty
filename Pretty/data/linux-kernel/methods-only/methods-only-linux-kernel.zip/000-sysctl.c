/* Note: sysrq code uses it's own private copy */
static int __sysrq_enabled = CONFIG_MAGIC_SYSRQ_DEFAULT_ENABLE;

static int sysrq_sysctl_handler(struct ctl_table *table, int write,
                                void __user *buffer, size_t *lenp,
                                loff_t *ppos)
{
        int error;

        error = proc_dointvec(table, write, buffer, lenp, ppos);
        if (error)
                return error;

        if (write)
                sysrq_toggle_support(__sysrq_enabled);

        return 0;
}

/**
 * free_dma - free a reserved system DMA channel
 * @dmanr: DMA channel number
 */
void free_dma(unsigned int dmanr)
{
        if (dmanr >= MAX_DMA_CHANNELS) {
                printk(KERN_WARNING "Trying to free DMA%d\n", dmanr);
                return;
        }

        if (xchg(&dma_chan_busy[dmanr].lock, 0) == 0) {
                printk(KERN_WARNING "Trying to free free DMA%d\n", dmanr);
                return;
        }

} /* free_dma */

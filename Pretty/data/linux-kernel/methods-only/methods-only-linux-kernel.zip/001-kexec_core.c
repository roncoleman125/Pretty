int sanity_check_segment_list(struct kimage *image)
{
        int result, i;
        unsigned long nr_segments = image->nr_segments;

        /*
         * Verify we have good destination addresses.  The caller is
         * responsible for making certain we don't attempt to load
         * the new image into invalid or reserved areas of RAM.  This
         * just verifies it is an address we can use.
         *
         * Since the kernel does everything in page size chunks ensure
         * the destination addresses are page aligned.  Too many
         * special cases crop of when we don't do this.  The most
         * insidious is getting overlapping destination addresses
         * simply because addresses are changed to page size
         * granularity.
         */
        result = -EADDRNOTAVAIL;
        for (i = 0; i < nr_segments; i++) {
                unsigned long mstart, mend;

                mstart = image->segment[i].mem;
                mend   = mstart + image->segment[i].memsz;
                if ((mstart & ~PAGE_MASK) || (mend & ~PAGE_MASK))
                        return result;
                if (mend >= KEXEC_DESTINATION_MEMORY_LIMIT)
                        return result;
        }

        /* Verify our destination addresses do not overlap.
         * If we alloed overlapping destination addresses
         * through very weird things can happen with no
         * easy explanation as one segment stops on another.
         */
        result = -EINVAL;
        for (i = 0; i < nr_segments; i++) {
                unsigned long mstart, mend;
                unsigned long j;

                mstart = image->segment[i].mem;
                mend   = mstart + image->segment[i].memsz;
                for (j = 0; j < i; j++) {
                        unsigned long pstart, pend;

                        pstart = image->segment[j].mem;
                        pend   = pstart + image->segment[j].memsz;
                        /* Do the segments overlap ? */
                        if ((mend > pstart) && (mstart < pend))
                                return result;
                }
        }

        /* Ensure our buffer sizes are strictly less than
         * our memory sizes.  This should always be the case,
         * and it is easier to check up front than to be surprised
         * later on.
         */
        result = -EINVAL;
        for (i = 0; i < nr_segments; i++) {
                if (image->segment[i].bufsz > image->segment[i].memsz)
                        return result;
        }

        /*
         * Verify we have good destination addresses.  Normally
         * the caller is responsible for making certain we don't
         * attempt to load the new image into invalid or reserved
         * areas of RAM.  But crash kernels are preloaded into a
         * reserved area of ram.  We must ensure the addresses
         * are in the reserved area otherwise preloading the
         * kernel could corrupt things.
         */

        if (image->type == KEXEC_TYPE_CRASH) {
                result = -EADDRNOTAVAIL;
                for (i = 0; i < nr_segments; i++) {
                        unsigned long mstart, mend;

                        mstart = image->segment[i].mem;
                        mend = mstart + image->segment[i].memsz - 1;
                        /* Ensure we are within the crash kernel limits */
                        if ((mstart < crashk_res.start) ||
                            (mend > crashk_res.end))
                                return result;
                }
        }

        return 0;
}

static inline void seccomp_assign_mode(struct task_struct *task,
                                       unsigned long seccomp_mode)
{
        assert_spin_locked(&task->sighand->siglock);

        task->seccomp.mode = seccomp_mode;
        /*
         * Make sure TIF_SECCOMP cannot be set before the mode (and
         * filter) is set.
         */
        smp_mb__before_atomic();
        set_tsk_thread_flag(task, TIF_SECCOMP);
}

/*
 * Walk curr->robust_list (very carefully, it's a userspace list!)
 * and mark any locks found there dead, and notify any waiters.
 *
 * We silently return on any sign of list-walking problem.
 */
void compat_exit_robust_list(struct task_struct *curr)
{
        struct compat_robust_list_head __user *head = curr->compat_robust_list;
        struct robust_list __user *entry, *next_entry, *pending;
        unsigned int limit = ROBUST_LIST_LIMIT, pi, pip;
        unsigned int uninitialized_var(next_pi);
        compat_uptr_t uentry, next_uentry, upending;
        compat_long_t futex_offset;
        int rc;

        if (!futex_cmpxchg_enabled)
                return;

        /*
         * Fetch the list head (which was registered earlier, via
         * sys_set_robust_list()):
         */
        if (fetch_robust_entry(&uentry, &entry, &head->list.next, &pi))
                return;
        /*
         * Fetch the relative futex offset:
         */
        if (get_user(futex_offset, &head->futex_offset))
                return;
        /*
         * Fetch any possibly pending lock-add first, and handle it
         * if it exists:
         */
        if (fetch_robust_entry(&upending, &pending,
                               &head->list_op_pending, &pip))
                return;

        next_entry = NULL;      /* avoid warning with gcc */
        while (entry != (struct robust_list __user *) &head->list) {
                /*
                 * Fetch the next entry in the list before calling
                 * handle_futex_death:
                 */
                rc = fetch_robust_entry(&next_uentry, &next_entry,
                        (compat_uptr_t __user *)&entry->next, &next_pi);
                /*
                 * A pending lock might already be on the list, so
                 * dont process it twice:
                 */
                if (entry != pending) {
                        void __user *uaddr = futex_uaddr(entry, futex_offset);

                        if (handle_futex_death(uaddr, curr, pi))
                                return;
                }
                if (rc)
                        return;
                uentry = next_uentry;
                entry = next_entry;
                pi = next_pi;
                /*
                 * Avoid excessively long or circular lists:
                 */
                if (!--limit)
                        break;

                cond_resched();
        }
        if (pending) {
                void __user *uaddr = futex_uaddr(pending, futex_offset);

                handle_futex_death(uaddr, curr, pip);
        }
}

void kernel_restart_prepare(char *cmd)
{
        blocking_notifier_call_chain(&reboot_notifier_list, SYS_RESTART, cmd);
        system_state = SYSTEM_RESTART;
        usermodehelper_disable();
        device_shutdown();
}

static int kcov_mmap(struct file *filep, struct vm_area_struct *vma)
{
        int res = 0;
        void *area;
        struct kcov *kcov = vma->vm_file->private_data;
        unsigned long size, off;
        struct page *page;

        area = vmalloc_user(vma->vm_end - vma->vm_start);
        if (!area)
                return -ENOMEM;

        spin_lock(&kcov->lock);
        size = kcov->size * sizeof(unsigned long);
        if (kcov->mode == KCOV_MODE_DISABLED || vma->vm_pgoff != 0 ||
            vma->vm_end - vma->vm_start != size) {
                res = -EINVAL;
                goto exit;
        }
        if (!kcov->area) {
                kcov->area = area;
                vma->vm_flags |= VM_DONTEXPAND;
                spin_unlock(&kcov->lock);
                for (off = 0; off < size; off += PAGE_SIZE) {
                        page = vmalloc_to_page(kcov->area + off);
                        if (vm_insert_page(vma, vma->vm_start + off, page))
                                WARN_ONCE(1, "vm_insert_page() failed");
                }
                return 0;
        }
exit:
        spin_unlock(&kcov->lock);
        vfree(area);
        return res;
}

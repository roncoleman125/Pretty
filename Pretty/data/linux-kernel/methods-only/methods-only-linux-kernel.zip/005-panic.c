/**
 *      print_tainted - return a string to represent the kernel taint state.
 *
 *  'P' - Proprietary module has been loaded.
 *  'F' - Module has been forcibly loaded.
 *  'S' - SMP with CPUs not designed for SMP.
 *  'R' - User forced a module unload.
 *  'M' - System experienced a machine check exception.
 *  'B' - System has hit bad_page.
 *  'U' - Userspace-defined naughtiness.
 *  'D' - Kernel has oopsed before
 *  'A' - ACPI table overridden.
 *  'W' - Taint on warning.
 *  'C' - modules from drivers/staging are loaded.
 *  'I' - Working around severe firmware bug.
 *  'O' - Out-of-tree module has been loaded.
 *  'E' - Unsigned module has been loaded.
 *  'L' - A soft lockup has previously occurred.
 *  'K' - Kernel has been live patched.
 *
 *      The string is overwritten by the next call to print_tainted().
 */
const char *print_tainted(void)
{
        static char buf[ARRAY_SIZE(tnts) + sizeof("Tainted: ")];

        if (tainted_mask) {
                char *s;
                int i;

                s = buf + sprintf(buf, "Tainted: ");
                for (i = 0; i < ARRAY_SIZE(tnts); i++) {
                        const struct tnt *t = &tnts[i];
                        *s++ = test_bit(t->bit, &tainted_mask) ?
                                        t->true : t->false;
                }
                *s = 0;
        } else
                snprintf(buf, sizeof(buf), "Not tainted");

        return buf;
}

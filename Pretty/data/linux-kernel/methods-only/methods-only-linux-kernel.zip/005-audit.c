static int audit_do_config_change(char *function_name, u32 *to_change, u32 new)
{
        int allow_changes, rc = 0;
        u32 old = *to_change;

        /* check if we are locked */
        if (audit_enabled == AUDIT_LOCKED)
                allow_changes = 0;
        else
                allow_changes = 1;

        if (audit_enabled != AUDIT_OFF) {
                rc = audit_log_config_change(function_name, new, old, allow_changes);
                if (rc)
                        allow_changes = 0;
        }

        /* If we are allowed, make the change */
        if (allow_changes == 1)
                *to_change = new;
        /* Not allowed, update reason */
        else if (rc == 0)
                rc = -EPERM;
        return rc;
}

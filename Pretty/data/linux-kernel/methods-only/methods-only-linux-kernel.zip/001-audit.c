void audit_panic(const char *message)
{
        switch (audit_failure) {
        case AUDIT_FAIL_SILENT:
                break;
        case AUDIT_FAIL_PRINTK:
                if (printk_ratelimit())
                        pr_err("%s\n", message);
                break;
        case AUDIT_FAIL_PANIC:
                /* test audit_pid since printk is always losey, why bother? */
                if (audit_pid)
                        panic("audit: %s\n", message);
                break;
        }
}

static void __put_chunk(struct rcu_head *rcu)
{
        struct audit_chunk *chunk = container_of(rcu, struct audit_chunk, head);
        audit_put_chunk(chunk);
}

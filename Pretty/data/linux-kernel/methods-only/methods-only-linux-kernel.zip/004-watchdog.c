static int __init nosoftlockup_setup(char *str)
{
        watchdog_enabled &= ~SOFT_WATCHDOG_ENABLED;
        return 1;
}

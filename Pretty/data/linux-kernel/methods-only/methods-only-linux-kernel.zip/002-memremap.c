static void *try_ram_remap(resource_size_t offset, size_t size)
{
        unsigned long pfn = PHYS_PFN(offset);

        /* In the simple case just return the existing linear address */
        if (pfn_valid(pfn) && !PageHighMem(pfn_to_page(pfn)))
                return __va(offset);
        return NULL; /* fallback to arch_memremap_wb */
}

static ssize_t kexec_loaded_show(struct kobject *kobj,
                                 struct kobj_attribute *attr, char *buf)
{
        return sprintf(buf, "%d\n", !!kexec_image);
}

static __always_inline bool
mod_tree_less(struct latch_tree_node *a, struct latch_tree_node *b)
{
        return __mod_tree_val(a) < __mod_tree_val(b);
}

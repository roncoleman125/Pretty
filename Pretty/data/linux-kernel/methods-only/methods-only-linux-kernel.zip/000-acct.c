/*
 * Check the amount of free space and suspend/resume accordingly.
 */
static int check_free_space(struct bsd_acct_struct *acct)
{
        struct kstatfs sbuf;

        if (time_is_before_jiffies(acct->needcheck))
                goto out;

        /* May block */
        if (vfs_statfs(&acct->file->f_path, &sbuf))
                goto out;

        if (acct->active) {
                u64 suspend = sbuf.f_blocks * SUSPEND;
                do_div(suspend, 100);
                if (sbuf.f_bavail <= suspend) {
                        acct->active = 0;
                        pr_info("Process accounting paused\n");
                }
        } else {
                u64 resume = sbuf.f_blocks * RESUME;
                do_div(resume, 100);
                if (sbuf.f_bavail >= resume) {
                        acct->active = 1;
                        pr_info("Process accounting resumed\n");
                }
        }

        acct->needcheck = jiffies + ACCT_TIMEOUT*HZ;
out:
        return acct->active;
}

static inline void release_probes(struct tracepoint_func *old)
{
        if (old) {
                struct tp_probes *tp_probes = container_of(old,
                        struct tp_probes, probes[0]);
                call_rcu_sched(&tp_probes->rcu, rcu_free_old_probes);
        }
}

/*
 *      Special case of dostring for the UTS structure. This has locks
 *      to observe. Should this be in kernel/sys.c ????
 */
static int proc_do_uts_string(struct ctl_table *table, int write,
                  void __user *buffer, size_t *lenp, loff_t *ppos)
{
        struct ctl_table uts_table;
        int r;
        memcpy(&uts_table, table, sizeof(uts_table));
        uts_table.data = get_uts(table, write);
        r = proc_dostring(&uts_table, write, buffer, lenp, ppos);
        put_uts(table, write, uts_table.data);

        if (write)
                proc_sys_poll_notify(table->poll);

        return r;
}

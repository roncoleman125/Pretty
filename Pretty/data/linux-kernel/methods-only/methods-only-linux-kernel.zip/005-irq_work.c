static void irq_work_run_list(struct llist_head *list)
{
        unsigned long flags;
        struct irq_work *work;
        struct llist_node *llnode;

        BUG_ON(!irqs_disabled());

        if (llist_empty(list))
                return;

        llnode = llist_del_all(list);
        while (llnode != NULL) {
                work = llist_entry(llnode, struct irq_work, llnode);

                llnode = llist_next(llnode);

                /*
                 * Clear the PENDING bit, after this point the @work
                 * can be re-used.
                 * Make it immediately visible so that other CPUs trying
                 * to claim that work don't rely on us to handle their data
                 * while we are in the middle of the func.
                 */
                flags = work->flags & ~IRQ_WORK_PENDING;
                xchg(&work->flags, flags);

                work->func(work);
                /*
                 * Clear the BUSY bit and return to the free state if
                 * no-one else claimed it meanwhile.
                 */
                (void)cmpxchg(&work->flags, flags, flags & ~IRQ_WORK_BUSY);
        }
}

int add_range(struct range *range, int az, int nr_range, u64 start, u64 end)
{
        if (start >= end)
                return nr_range;

        /* Out of slots: */
        if (nr_range >= az)
                return nr_range;

        range[nr_range].start = start;
        range[nr_range].end = end;

        nr_range++;

        return nr_range;
}

void cpu_maps_update_done(void)
{
        mutex_unlock(&cpu_add_remove_lock);
}

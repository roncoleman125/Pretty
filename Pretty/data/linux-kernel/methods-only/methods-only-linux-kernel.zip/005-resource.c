static int r_show(struct seq_file *m, void *v)
{
        struct resource *root = m->private;
        struct resource *r = v, *p;
        unsigned long long start, end;
        int width = root->end < 0x10000 ? 4 : 8;
        int depth;

        for (depth = 0, p = r; depth < MAX_IORES_LEVEL; depth++, p = p->parent)
                if (p->parent == root)
                        break;

        if (file_ns_capable(m->file, &init_user_ns, CAP_SYS_ADMIN)) {
                start = r->start;
                end = r->end;
        } else {
                start = end = 0;
        }

        seq_printf(m, "%*s%0*llx-%0*llx : %s\n",
                        depth * 2, "",
                        width, start,
                        width, end,
                        r->name ? r->name : "<BAD>");
        return 0;
}

static int kimage_alloc_init(struct kimage **rimage, unsigned long entry,
                             unsigned long nr_segments,
                             struct kexec_segment __user *segments,
                             unsigned long flags)
{
        int ret;
        struct kimage *image;
        bool kexec_on_panic = flags & KEXEC_ON_CRASH;

        if (kexec_on_panic) {
                /* Verify we have a valid entry point */
                if ((entry < crashk_res.start) || (entry > crashk_res.end))
                        return -EADDRNOTAVAIL;
        }

        /* Allocate and initialize a controlling structure */
        image = do_kimage_alloc_init();
        if (!image)
                return -ENOMEM;

        image->start = entry;

        ret = copy_user_segment_list(image, nr_segments, segments);
        if (ret)
                goto out_free_image;

        if (kexec_on_panic) {
                /* Enable special crash kernel control page alloc policy. */
                image->control_page = crashk_res.start;
                image->type = KEXEC_TYPE_CRASH;
        }

        ret = sanity_check_segment_list(image);
        if (ret)
                goto out_free_image;

        /*
         * Find a location for the control code buffer, and add it
         * the vector of segments so that it's pages will also be
         * counted as destination pages.
         */
        ret = -ENOMEM;
        image->control_code_page = kimage_alloc_control_pages(image,
                                           get_order(KEXEC_CONTROL_PAGE_SIZE));
        if (!image->control_code_page) {
                pr_err("Could not allocate control_code_buffer\n");
                goto out_free_image;
        }

        if (!kexec_on_panic) {
                image->swap_page = kimage_alloc_control_pages(image, 0);
                if (!image->swap_page) {
                        pr_err("Could not allocate swap buffer\n");
                        goto out_free_control_pages;
                }
        }

        *rimage = image;
        return 0;
out_free_control_pages:
        kimage_free_page_list(&image->control_pages);
out_free_image:
        kfree(image);
        return ret;
}

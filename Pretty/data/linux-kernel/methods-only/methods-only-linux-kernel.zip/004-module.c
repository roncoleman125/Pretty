static noinline void __mod_tree_insert(struct mod_tree_node *node)
{
        latch_tree_insert(&node->node, &mod_tree.root, &mod_tree_ops);
}

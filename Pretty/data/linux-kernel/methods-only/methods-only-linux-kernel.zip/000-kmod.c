static void free_modprobe_argv(struct subprocess_info *info)
{
        kfree(info->argv[3]); /* check call_modprobe() */
        kfree(info->argv);
}

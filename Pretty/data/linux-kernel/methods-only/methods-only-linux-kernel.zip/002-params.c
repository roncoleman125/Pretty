static void *kmalloc_parameter(unsigned int size)
{
        struct kmalloced_param *p;

        p = kmalloc(sizeof(*p) + size, GFP_KERNEL);
        if (!p)
                return NULL;

        spin_lock(&kmalloced_params_lock);
        list_add(&p->list, &kmalloced_params);
        spin_unlock(&kmalloced_params_lock);

        return p->val;
}

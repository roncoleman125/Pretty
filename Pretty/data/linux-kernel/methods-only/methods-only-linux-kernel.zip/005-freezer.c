/**
 * set_freezable - make %current freezable
 *
 * Mark %current freezable and enter refrigerator if necessary.
 */
bool set_freezable(void)
{
        might_sleep();

        /*
         * Modify flags while holding freezer_lock.  This ensures the
         * freezer notices that we aren't frozen yet or the freezing
         * condition is visible to try_to_freeze() below.
         */
        spin_lock_irq(&freezer_lock);
        current->flags &= ~PF_NOFREEZE;
        spin_unlock_irq(&freezer_lock);

        return try_to_freeze();
}

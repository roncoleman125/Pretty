static ssize_t profiling_store(struct kobject *kobj,
                                   struct kobj_attribute *attr,
                                   const char *buf, size_t count)
{
        int ret;

        if (prof_on)
                return -EEXIST;
        /*
         * This eventually calls into get_option() which
         * has a ton of callers and is not const.  It is
         * easiest to cast it away here.
         */
        profile_setup((char *)buf);
        ret = profile_init();
        if (ret)
                return ret;
        ret = create_proc_profile();
        if (ret)
                return ret;
        return count;
}

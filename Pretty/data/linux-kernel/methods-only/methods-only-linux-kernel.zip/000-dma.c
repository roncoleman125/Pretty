/**
 * request_dma - request and reserve a system DMA channel
 * @dmanr: DMA channel number
 * @device_id: reserving device ID string, used in /proc/dma
 */
int request_dma(unsigned int dmanr, const char * device_id)
{
        if (dmanr >= MAX_DMA_CHANNELS)
                return -EINVAL;

        if (xchg(&dma_chan_busy[dmanr].lock, 1) != 0)
                return -EBUSY;

        dma_chan_busy[dmanr].device_id = device_id;

        /* old flag was 0, now contains 1 to indicate busy */
        return 0;
} /* request_dma */

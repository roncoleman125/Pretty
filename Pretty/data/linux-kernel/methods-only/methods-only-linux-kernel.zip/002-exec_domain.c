static int __init proc_execdomains_init(void)
{
        proc_create("execdomains", 0, NULL, &execdomains_proc_fops);
        return 0;
}

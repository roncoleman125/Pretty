int __weak elf_core_write_extra_data(struct coredump_params *cprm)
{
        return 1;
}

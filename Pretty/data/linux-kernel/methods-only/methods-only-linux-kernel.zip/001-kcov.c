static void kcov_get(struct kcov *kcov)
{
        atomic_inc(&kcov->refcount);
}

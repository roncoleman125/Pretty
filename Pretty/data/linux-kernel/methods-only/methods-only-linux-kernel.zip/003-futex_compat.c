COMPAT_SYSCALL_DEFINE2(set_robust_list,
                struct compat_robust_list_head __user *, head,
                compat_size_t, len)
{
        if (!futex_cmpxchg_enabled)
                return -ENOSYS;

        if (unlikely(len != sizeof(*head)))
                return -EINVAL;

        current->compat_robust_list = head;

        return 0;
}

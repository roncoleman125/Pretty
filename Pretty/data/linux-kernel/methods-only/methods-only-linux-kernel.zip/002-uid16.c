SYSCALL_DEFINE3(fchown16, unsigned int, fd, old_uid_t, user, old_gid_t, group)
{
        return sys_fchown(fd, low2highuid(user), low2highgid(group));
}

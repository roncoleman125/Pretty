static void fill_stats(struct user_namespace *user_ns,
                       struct pid_namespace *pid_ns,
                       struct task_struct *tsk, struct taskstats *stats)
{
        memset(stats, 0, sizeof(*stats));
        /*
         * Each accounting subsystem adds calls to its functions to
         * fill in relevant parts of struct taskstsats as follows
         *
         *      per-task-foo(stats, tsk);
         */

        delayacct_add_tsk(stats, tsk);

        /* fill in basic acct fields */
        stats->version = TASKSTATS_VERSION;
        stats->nvcsw = tsk->nvcsw;
        stats->nivcsw = tsk->nivcsw;
        bacct_add_tsk(user_ns, pid_ns, stats, tsk);

        /* fill in extended acct fields */
        xacct_add_tsk(stats, tsk);
}

static struct cgroup_subsys_state *
freezer_css_alloc(struct cgroup_subsys_state *parent_css)
{
        struct freezer *freezer;

        freezer = kzalloc(sizeof(struct freezer), GFP_KERNEL);
        if (!freezer)
                return ERR_PTR(-ENOMEM);

        return &freezer->css;
}

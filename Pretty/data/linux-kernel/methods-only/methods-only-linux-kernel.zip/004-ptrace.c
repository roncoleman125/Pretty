/**
 * ptrace_check_attach - check whether ptracee is ready for ptrace operation
 * @child: ptracee to check for
 * @ignore_state: don't check whether @child is currently %TASK_TRACED
 *
 * Check whether @child is being ptraced by %current and ready for further
 * ptrace operations.  If @ignore_state is %false, @child also should be in
 * %TASK_TRACED state and on return the child is guaranteed to be traced
 * and not executing.  If @ignore_state is %true, @child can be in any
 * state.
 *
 * CONTEXT:
 * Grabs and releases tasklist_lock and @child->sighand->siglock.
 *
 * RETURNS:
 * 0 on success, -ESRCH if %child is not ready.
 */
static int ptrace_check_attach(struct task_struct *child, bool ignore_state)
{
        int ret = -ESRCH;

        /*
         * We take the read lock around doing both checks to close a
         * possible race where someone else was tracing our child and
         * detached between these two checks.  After this locked check,
         * we are sure that this is our traced child and that can only
         * be changed by us so it's not changing right after this.
         */
        read_lock(&tasklist_lock);
        if (child->ptrace && child->parent == current) {
                WARN_ON(child->state == __TASK_TRACED);
                /*
                 * child->sighand can't be NULL, release_task()
                 * does ptrace_unlink() before __exit_signal().
                 */
                if (ignore_state || ptrace_freeze_traced(child))
                        ret = 0;
        }
        read_unlock(&tasklist_lock);

        if (!ret && !ignore_state) {
                if (!wait_task_inactive(child, __TASK_TRACED)) {
                        /*
                         * This can only happen if may_ptrace_stop() fails and
                         * ptrace_stop() changes ->state back to TASK_RUNNING,
                         * so we should not worry about leaking __TASK_TRACED.
                         */
                        WARN_ON(child->state == __TASK_TRACED);
                        ret = -ESRCH;
                }
        }

        return ret;
}

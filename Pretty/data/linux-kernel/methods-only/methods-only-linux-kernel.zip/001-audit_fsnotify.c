static void audit_fsnotify_free_mark(struct fsnotify_mark *mark)
{
        struct audit_fsnotify_mark *audit_mark;

        audit_mark = container_of(mark, struct audit_fsnotify_mark, mark);
        audit_fsnotify_mark_free(audit_mark);
}

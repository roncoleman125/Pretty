static void *cgroup_idr_replace(struct idr *idr, void *ptr, int id)
{
        void *ret;

        spin_lock_bh(&cgroup_idr_lock);
        ret = idr_replace(idr, ptr, id);
        spin_unlock_bh(&cgroup_idr_lock);
        return ret;
}

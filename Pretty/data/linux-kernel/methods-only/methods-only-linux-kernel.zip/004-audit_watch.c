/*
 * Find and return the audit_parent on the given inode.  If found a reference
 * is taken on this parent.
 */
static inline struct audit_parent *audit_find_parent(struct inode *inode)
{
        struct audit_parent *parent = NULL;
        struct fsnotify_mark *entry;

        entry = fsnotify_find_inode_mark(audit_watch_group, inode);
        if (entry)
                parent = container_of(entry, struct audit_parent, mark);

        return parent;
}

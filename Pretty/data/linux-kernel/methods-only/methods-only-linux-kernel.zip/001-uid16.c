SYSCALL_DEFINE3(lchown16, const char __user *, filename, old_uid_t, user, old_gid_t, group)
{
        return sys_lchown(filename, low2highuid(user), low2highgid(group));
}

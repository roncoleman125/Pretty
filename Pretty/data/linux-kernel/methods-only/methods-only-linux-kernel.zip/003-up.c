/*
 * Note we still need to test the mask even for UP
 * because we actually can get an empty mask from
 * code that on SMP might call us without the local
 * CPU in the mask.
 */
void on_each_cpu_mask(const struct cpumask *mask,
                      smp_call_func_t func, void *info, bool wait)
{
        unsigned long flags;

        if (cpumask_test_cpu(0, mask)) {
                local_irq_save(flags);
                func(info);
                local_irq_restore(flags);
        }
}

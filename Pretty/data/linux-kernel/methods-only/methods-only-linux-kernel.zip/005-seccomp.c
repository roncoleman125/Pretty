/* Returns 1 if the parent is an ancestor of the child. */
static int is_ancestor(struct seccomp_filter *parent,
                       struct seccomp_filter *child)
{
        /* NULL is the root ancestor. */
        if (parent == NULL)
                return 1;
        for (; child; child = child->prev)
                if (child == parent)
                        return 1;
        return 0;
}

/* Return 1 if all garbages are collected, otherwise 0. */
static int collect_one_slot(struct kprobe_insn_page *kip, int idx)
{
        kip->slot_used[idx] = SLOT_CLEAN;
        kip->nused--;
        if (kip->nused == 0) {
                /*
                 * Page is no longer in use.  Free it unless
                 * it's the last one.  We keep the last one
                 * so as not to have to set it up again the
                 * next time somebody inserts a probe.
                 */
                if (!list_is_singular(&kip->list)) {
                        list_del(&kip->list);
                        kip->cache->free(kip->insns);
                        kfree(kip);
                }
                return 1;
        }
        return 0;
}

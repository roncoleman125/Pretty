struct audit_fsnotify_mark *audit_alloc_mark(struct audit_krule *krule, char *pathname, int len)
{
        struct audit_fsnotify_mark *audit_mark;
        struct path path;
        struct dentry *dentry;
        struct inode *inode;
        int ret;

        if (pathname[0] != '/' || pathname[len-1] == '/')
                return ERR_PTR(-EINVAL);

        dentry = kern_path_locked(pathname, &path);
        if (IS_ERR(dentry))
                return (void *)dentry; /* returning an error */
        inode = path.dentry->d_inode;
        inode_unlock(inode);

        audit_mark = kzalloc(sizeof(*audit_mark), GFP_KERNEL);
        if (unlikely(!audit_mark)) {
                audit_mark = ERR_PTR(-ENOMEM);
                goto out;
        }

        fsnotify_init_mark(&audit_mark->mark, audit_fsnotify_free_mark);
        audit_mark->mark.mask = AUDIT_FS_EVENTS;
        audit_mark->path = pathname;
        audit_update_mark(audit_mark, dentry->d_inode);
        audit_mark->rule = krule;

        ret = fsnotify_add_mark(&audit_mark->mark, audit_fsnotify_group, inode, NULL, true);
        if (ret < 0) {
                audit_fsnotify_mark_free(audit_mark);
                audit_mark = ERR_PTR(ret);
        }
out:
        dput(dentry);
        path_put(&path);
        return audit_mark;
}

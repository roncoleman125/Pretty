static void *func_remove(struct tracepoint_func **funcs,
                struct tracepoint_func *tp_func)
{
        int nr_probes = 0, nr_del = 0, i;
        struct tracepoint_func *old, *new;

        old = *funcs;

        if (!old)
                return ERR_PTR(-ENOENT);

        debug_print_probes(*funcs);
        /* (N -> M), (N > 1, M >= 0) probes */
        if (tp_func->func) {
                for (nr_probes = 0; old[nr_probes].func; nr_probes++) {
                        if (old[nr_probes].func == tp_func->func &&
                             old[nr_probes].data == tp_func->data)
                                nr_del++;
                }
        }

        /*
         * If probe is NULL, then nr_probes = nr_del = 0, and then the
         * entire entry will be removed.
         */
        if (nr_probes - nr_del == 0) {
                /* N -> 0, (N > 1) */
                *funcs = NULL;
                debug_print_probes(*funcs);
                return old;
        } else {
                int j = 0;
                /* N -> M, (N > 1, M > 0) */
                /* + 1 for NULL */
                new = allocate_probes(nr_probes - nr_del + 1);
                if (new == NULL)
                        return ERR_PTR(-ENOMEM);
                for (i = 0; old[i].func; i++)
                        if (old[i].func != tp_func->func
                                        || old[i].data != tp_func->data)
                                new[j++] = old[i];
                new[nr_probes - nr_del].func = NULL;
                *funcs = new;
        }
        debug_print_probes(*funcs);
        return old;
}

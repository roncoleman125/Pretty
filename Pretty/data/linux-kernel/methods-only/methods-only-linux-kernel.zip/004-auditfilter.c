/* Unpack a filter field's string representation from user-space
 * buffer. */
char *audit_unpack_string(void **bufp, size_t *remain, size_t len)
{
        char *str;

        if (!*bufp || (len == 0) || (len > *remain))
                return ERR_PTR(-EINVAL);

        /* Of the currently implemented string fields, PATH_MAX
         * defines the longest valid length.
         */
        if (len > PATH_MAX)
                return ERR_PTR(-ENAMETOOLONG);

        str = kmalloc(len + 1, GFP_KERNEL);
        if (unlikely(!str))
                return ERR_PTR(-ENOMEM);

        memcpy(str, *bufp, len);
        str[len] = 0;
        *bufp += len;
        *remain -= len;

        return str;
}

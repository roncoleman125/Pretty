void memunmap(void *addr)
{
        if (is_vmalloc_addr(addr))
                iounmap((void __iomem *) addr);
}

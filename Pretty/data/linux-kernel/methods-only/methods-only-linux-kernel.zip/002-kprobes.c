static void *alloc_insn_page(void)
{
        return module_alloc(PAGE_SIZE);
}

/*
 * Claim the entry so that no one else will poke at it.
 */
static bool irq_work_claim(struct irq_work *work)
{
        unsigned long flags, oflags, nflags;

        /*
         * Start with our best wish as a premise but only trust any
         * flag value after cmpxchg() result.
         */
        flags = work->flags & ~IRQ_WORK_PENDING;
        for (;;) {
                nflags = flags | IRQ_WORK_FLAGS;
                oflags = cmpxchg(&work->flags, flags, nflags);
                if (oflags == flags)
                        break;
                if (oflags & IRQ_WORK_PENDING)
                        return false;
                flags = oflags;
                cpu_relax();
        }

        return true;
}

/* Does nothing if parameter wasn't kmalloced above. */
static void maybe_kfree_parameter(void *param)
{
        struct kmalloced_param *p;

        spin_lock(&kmalloced_params_lock);
        list_for_each_entry(p, &kmalloced_params, list) {
                if (p->val == param) {
                        list_del(&p->list);
                        kfree(p);
                        break;
                }
        }
        spin_unlock(&kmalloced_params_lock);
}

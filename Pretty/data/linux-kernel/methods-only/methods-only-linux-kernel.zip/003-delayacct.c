/*
 * Finish delay accounting for a statistic using its timestamps (@start),
 * accumalator (@total) and @count
 */
static void delayacct_end(u64 *start, u64 *total, u32 *count)
{
        s64 ns = ktime_get_ns() - *start;
        unsigned long flags;

        if (ns > 0) {
                spin_lock_irqsave(&current->delays->lock, flags);
                *total += ns;
                (*count)++;
                spin_unlock_irqrestore(&current->delays->lock, flags);
        }
}

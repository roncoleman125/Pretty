static int __init hardlockup_panic_setup(char *str)
{
        if (!strncmp(str, "panic", 5))
                hardlockup_panic = 1;
        else if (!strncmp(str, "nopanic", 7))
                hardlockup_panic = 0;
        else if (!strncmp(str, "0", 1))
                watchdog_enabled &= ~NMI_WATCHDOG_ENABLED;
        else if (!strncmp(str, "1", 1))
                watchdog_enabled |= NMI_WATCHDOG_ENABLED;
        return 1;
}

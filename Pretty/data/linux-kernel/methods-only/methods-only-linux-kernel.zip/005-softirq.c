/*
 * When we run softirqs from irq_exit() and thus on the hardirq stack we need
 * to keep the lockdep irq context tracking as tight as possible in order to
 * not miss-qualify lock contexts and miss possible deadlocks.
 */

static inline bool lockdep_softirq_start(void)
{
        bool in_hardirq = false;

        if (trace_hardirq_context(current)) {
                in_hardirq = true;
                trace_hardirq_exit();
        }

        lockdep_softirq_enter();

        return in_hardirq;
}

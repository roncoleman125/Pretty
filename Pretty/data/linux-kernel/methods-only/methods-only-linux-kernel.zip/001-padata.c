static int padata_cpu_hash(struct parallel_data *pd)
{
        unsigned int seq_nr;
        int cpu_index;

        /*
         * Hash the sequence numbers to the cpus by taking
         * seq_nr mod. number of cpus in use.
         */

        seq_nr = atomic_inc_return(&pd->seq_nr);
        cpu_index = seq_nr % cpumask_weight(pd->cpumask.pcpu);

        return padata_index_to_cpu(pd, cpu_index);
}

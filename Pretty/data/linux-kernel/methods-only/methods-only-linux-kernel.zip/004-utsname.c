static inline struct uts_namespace *to_uts_ns(struct ns_common *ns)
{
        return container_of(ns, struct uts_namespace, ns);
}

static bool cgroup_ssid_no_v1(int ssid)
{
        return cgroup_no_v1_mask & (1 << ssid);
}

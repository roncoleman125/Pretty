void switch_task_namespaces(struct task_struct *p, struct nsproxy *new)
{
        struct nsproxy *ns;

        might_sleep();

        task_lock(p);
        ns = p->nsproxy;
        p->nsproxy = new;
        task_unlock(p);

        if (ns && atomic_dec_and_test(&ns->count))
                free_nsproxy(ns);
}

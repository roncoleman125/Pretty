static void exitf(void)
{
}

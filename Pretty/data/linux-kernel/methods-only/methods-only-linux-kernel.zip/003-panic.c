/*
 * A variant of panic() called from NMI context. We return if we've already
 * panicked on this CPU. If another CPU already panicked, loop in
 * nmi_panic_self_stop() which can provide architecture dependent code such
 * as saving register state for crash dump.
 */
void nmi_panic(struct pt_regs *regs, const char *msg)
{
        int old_cpu, cpu;

        cpu = raw_smp_processor_id();
        old_cpu = atomic_cmpxchg(&panic_cpu, PANIC_CPU_INVALID, cpu);

        if (old_cpu == PANIC_CPU_INVALID)
                panic("%s", msg);
        else if (old_cpu != cpu)
                nmi_panic_self_stop(regs);
}

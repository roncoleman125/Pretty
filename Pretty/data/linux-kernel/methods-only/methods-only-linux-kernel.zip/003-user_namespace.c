void free_user_ns(struct user_namespace *ns)
{
        struct user_namespace *parent;

        do {
                parent = ns->parent;
//#ifdef CONFIG_PERSISTENT_KEYRINGS
                key_put(ns->persistent_keyring_register);
//#endif
                ns_free_inum(&ns->ns);
                kmem_cache_free(user_ns_cachep, ns);
                ns = parent;
        } while (atomic_dec_and_test(&parent->count));
}

void kcov_task_exit(struct task_struct *t)
{
        struct kcov *kcov;

        kcov = t->kcov;
        if (kcov == NULL)
                return;
        spin_lock(&kcov->lock);
        if (WARN_ON(kcov->t != t)) {
                spin_unlock(&kcov->lock);
                return;
        }
        /* Just to not leave dangling references behind. */
        kcov_task_init(t);
        kcov->t = NULL;
        spin_unlock(&kcov->lock);
        kcov_put(kcov);
}

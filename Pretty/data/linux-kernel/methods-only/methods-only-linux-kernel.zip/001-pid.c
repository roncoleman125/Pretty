static void free_pidmap(struct upid *upid)
{
        int nr = upid->nr;
        struct pidmap *map = upid->ns->pidmap + nr / BITS_PER_PAGE;
        int offset = nr & BITS_PER_PAGE_MASK;

        clear_bit(offset, map->page);
        atomic_inc(&map->nr_free);
}

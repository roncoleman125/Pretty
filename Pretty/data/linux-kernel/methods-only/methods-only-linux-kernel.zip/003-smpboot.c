/**
 * idle_threads_init - Initialize idle threads for all cpus
 */
void __init idle_threads_init(void)
{
        unsigned int cpu, boot_cpu;

        boot_cpu = smp_processor_id();

        for_each_possible_cpu(cpu) {
                if (cpu != boot_cpu)
                        idle_init(cpu);
        }
}

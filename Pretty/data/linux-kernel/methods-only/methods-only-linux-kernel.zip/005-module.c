static void __mod_tree_remove(struct mod_tree_node *node)
{
        latch_tree_erase(&node->node, &mod_tree.root, &mod_tree_ops);
}

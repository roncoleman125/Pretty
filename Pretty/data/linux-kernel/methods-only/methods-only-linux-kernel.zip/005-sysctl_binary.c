static const struct bin_table *get_sysctl(const int *name, int nlen, char *path)
{
        const struct bin_table *table = &bin_root_table[0];
        int ctl_name;

        /* The binary sysctl tables have a small maximum depth so
         * there is no danger of overflowing our path as it PATH_MAX
         * bytes long.
         */
        memcpy(path, "sys/", 4);
        path += 4;

repeat:
        if (!nlen)
                return ERR_PTR(-ENOTDIR);
        ctl_name = *name;
        name++;
        nlen--;
        for ( ; table->convert; table++) {
                int len = 0;

                /*
                 * For a wild card entry map from ifindex to network
                 * device name.
                 */
                if (!table->ctl_name) {
//#ifdef CONFIG_NET
                        struct net *net = current->nsproxy->net_ns;
                        struct net_device *dev;
                        dev = dev_get_by_index(net, ctl_name);
                        if (dev) {
                                len = strlen(dev->name);
                                memcpy(path, dev->name, len);
                                dev_put(dev);
                        }
//#endif
                /* Use the well known sysctl number to proc name mapping */
                } else if (ctl_name == table->ctl_name) {
                        len = strlen(table->procname);
                        memcpy(path, table->procname, len);
                }
                if (len) {
                        path += len;
                        if (table->child) {
                                *path++ = '/';
                                table = table->child;
                                goto repeat;
                        }
                        *path = '\0';
                        return table;
                }
        }
        return ERR_PTR(-ENOTDIR);
}

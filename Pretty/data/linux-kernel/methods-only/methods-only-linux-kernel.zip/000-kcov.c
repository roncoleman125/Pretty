/*
 * Entry point from instrumented code.
 * This is called once per basic-block/edge.
 */
void notrace __sanitizer_cov_trace_pc(void)
{
        struct task_struct *t;
        enum kcov_mode mode;

        t = current;
        /*
         * We are interested in code coverage as a function of a syscall inputs,
         * so we ignore code executed in interrupts.
         */
        if (!t || in_interrupt())
                return;
        mode = READ_ONCE(t->kcov_mode);
        if (mode == KCOV_MODE_TRACE) {
                unsigned long *area;
                unsigned long pos;

                /*
                 * There is some code that runs in interrupts but for which
                 * in_interrupt() returns false (e.g. preempt_schedule_irq()).
                 * READ_ONCE()/barrier() effectively provides load-acquire wrt
                 * interrupts, there are paired barrier()/WRITE_ONCE() in
                 * kcov_ioctl_locked().
                 */
                barrier();
                area = t->kcov_area;
                /* The first word is number of subsequent PCs. */
                pos = READ_ONCE(area[0]) + 1;
                if (likely(pos < t->kcov_size)) {
                        area[pos] = _RET_IP_;
                        WRITE_ONCE(area[0], pos);
                }
        }
}

SYSCALL_DEFINE2(setreuid16, old_uid_t, ruid, old_uid_t, euid)
{
        return sys_setreuid(low2highuid(ruid), low2highuid(euid));
}

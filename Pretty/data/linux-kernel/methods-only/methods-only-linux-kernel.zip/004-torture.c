/*
 * Were all the online/offline operations successful?
 */
bool torture_onoff_failures(void)
{
//#ifdef CONFIG_HOTPLUG_CPU
        return n_online_successes != n_online_attempts ||
               n_offline_successes != n_offline_attempts;
//#else /* #ifdef CONFIG_HOTPLUG_CPU */
        return false;
//#endif /* #else #ifdef CONFIG_HOTPLUG_CPU */
}

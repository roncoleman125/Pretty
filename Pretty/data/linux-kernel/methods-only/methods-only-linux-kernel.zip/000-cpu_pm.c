static int cpu_pm_notify(enum cpu_pm_event event, int nr_to_call, int *nr_calls)
{
        int ret;

        ret = __raw_notifier_call_chain(&cpu_pm_notifier_chain, event, NULL,
                nr_to_call, nr_calls);

        return notifier_to_errno(ret);
}

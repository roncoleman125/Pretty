/*
 * Initiate online-offline handling.
 */
int torture_onoff_init(long ooholdoff, long oointerval)
{
        int ret = 0;

//#ifdef CONFIG_HOTPLUG_CPU
        onoff_holdoff = ooholdoff;
        onoff_interval = oointerval;
        if (onoff_interval <= 0)
                return 0;
        ret = torture_create_kthread(torture_onoff, NULL, onoff_task);
//#endif /* #ifdef CONFIG_HOTPLUG_CPU */
        return ret;
}

/*
 * Iterator to store a backtrace into a latency record entry
 */
static inline void store_stacktrace(struct task_struct *tsk,
                                        struct latency_record *lat)
{
        struct stack_trace trace;

        memset(&trace, 0, sizeof(trace));
        trace.max_entries = LT_BACKTRACEDEPTH;
        trace.entries = &lat->backtrace[0];
        save_stack_trace_tsk(tsk, &trace);
}

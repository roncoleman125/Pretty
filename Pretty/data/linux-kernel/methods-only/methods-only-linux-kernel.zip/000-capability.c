static int __init file_caps_disable(char *str)
{
        file_caps_enabled = 0;
        return 1;
}

int on_each_cpu(smp_call_func_t func, void *info, int wait)
{
        unsigned long flags;

        local_irq_save(flags);
        func(info);
        local_irq_restore(flags);
        return 0;
}

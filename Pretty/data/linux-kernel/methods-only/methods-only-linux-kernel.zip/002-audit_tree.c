static inline void put_tree(struct audit_tree *tree)
{
        if (atomic_dec_and_test(&tree->count))
                kfree_rcu(tree, head);
}

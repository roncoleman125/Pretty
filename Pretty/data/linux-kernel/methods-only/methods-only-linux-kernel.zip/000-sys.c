/*
 * Returns true if current's euid is same as p's uid or euid,
 * or has CAP_SYS_NICE to p's user_ns.
 *
 * Called with rcu_read_lock, creds are safe
 */
static bool set_one_prio_perm(struct task_struct *p)
{
        const struct cred *cred = current_cred(), *pcred = __task_cred(p);

        if (uid_eq(pcred->uid,  cred->euid) ||
            uid_eq(pcred->euid, cred->euid))
                return true;
        if (ns_capable(pcred->user_ns, CAP_SYS_NICE))
                return true;
        return false;
}

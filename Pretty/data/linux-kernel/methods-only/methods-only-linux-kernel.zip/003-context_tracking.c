void context_tracking_enter(enum ctx_state state)
{
        unsigned long flags;

        /*
         * Some contexts may involve an exception occuring in an irq,
         * leading to that nesting:
         * rcu_irq_enter() rcu_user_exit() rcu_user_exit() rcu_irq_exit()
         * This would mess up the dyntick_nesting count though. And rcu_irq_*()
         * helpers are enough to protect RCU uses inside the exception. So
         * just return immediately if we detect we are in an IRQ.
         */
        if (in_interrupt())
                return;

        local_irq_save(flags);
        __context_tracking_enter(state);
        local_irq_restore(flags);
}

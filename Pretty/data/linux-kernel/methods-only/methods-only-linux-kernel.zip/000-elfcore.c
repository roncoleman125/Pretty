Elf_Half __weak elf_core_extra_phdrs(void)
{
        return 0;
}

static int padata_index_to_cpu(struct parallel_data *pd, int cpu_index)
{
        int cpu, target_cpu;

        target_cpu = cpumask_first(pd->cpumask.pcpu);
        for (cpu = 0; cpu < cpu_index; cpu++)
                target_cpu = cpumask_next(target_cpu, pd->cpumask.pcpu);

        return target_cpu;
}

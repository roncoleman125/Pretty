static ssize_t
ikconfig_read_current(struct file *file, char __user *buf,
                      size_t len, loff_t * offset)
{
        return simple_read_from_buffer(buf, len, offset,
                                       kernel_config_data + MAGIC_SIZE,
                                       kernel_config_data_size);
}

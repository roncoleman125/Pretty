static int __init hung_task_panic_setup(char *str)
{
        int rc = kstrtouint(str, 0, &sysctl_hung_task_panic);

        if (rc)
                return rc;
        return 1;
}

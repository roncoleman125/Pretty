int __init audit_register_class(int class, unsigned *list)
{
        __u32 *p = kcalloc(AUDIT_BITMASK_SIZE, sizeof(__u32), GFP_KERNEL);
        if (!p)
                return -ENOMEM;
        while (*list != ~0U) {
                unsigned n = *list++;
                if (n >= AUDIT_BITMASK_SIZE * 32 - AUDIT_SYSCALL_CLASSES) {
                        kfree(p);
                        return -EINVAL;
                }
                p[AUDIT_WORD(n)] |= AUDIT_BIT(n);
        }
        if (class >= AUDIT_SYSCALL_CLASSES || classes[class]) {
                kfree(p);
                return -EINVAL;
        }
        classes[class] = p;
        return 0;
}

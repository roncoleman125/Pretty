void audit_get_watch(struct audit_watch *watch)
{
        atomic_inc(&watch->count);
}

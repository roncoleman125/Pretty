static void kp_post_handler(struct kprobe *p, struct pt_regs *regs,
                unsigned long flags)
{
        if (preh_val != (rand1 / div_factor)) {
                handler_errors++;
                pr_err("incorrect value in post_handler\n");
        }
        posth_val = preh_val + div_factor;
}

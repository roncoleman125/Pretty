void profile_munmap(unsigned long addr)
{
        blocking_notifier_call_chain(&munmap_notifier, 0, (void *)addr);
}

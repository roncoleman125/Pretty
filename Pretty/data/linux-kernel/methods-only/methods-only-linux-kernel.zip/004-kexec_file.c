/* Apply relocations of type RELA */
int __weak
arch_kexec_apply_relocations_add(const Elf_Ehdr *ehdr, Elf_Shdr *sechdrs,
                                 unsigned int relsec)
{
        pr_err("RELA relocation unsupported.\n");
        return -ENOEXEC;
}

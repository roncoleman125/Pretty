/* signal completion unless @done is NULL */
static void cpu_stop_signal_done(struct cpu_stop_done *done)
{
        if (atomic_dec_and_test(&done->nr_todo))
                complete(&done->completion);
}

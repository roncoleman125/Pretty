void __weak arch_release_thread_stack(unsigned long *stack)
{
}

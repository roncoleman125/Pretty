static long hung_timeout_jiffies(unsigned long last_checked,
                                 unsigned long timeout)
{
        /* timeout of 0 will disable the watchdog */
        return timeout ? last_checked - jiffies + timeout * HZ :
                MAX_SCHEDULE_TIMEOUT;
}

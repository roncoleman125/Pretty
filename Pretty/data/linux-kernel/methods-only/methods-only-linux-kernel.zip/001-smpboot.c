void __init idle_thread_set_boot_cpu(void)
{
        per_cpu(idle_threads, smp_processor_id()) = current;
}

static void audit_mark_log_rule_change(struct audit_fsnotify_mark *audit_mark, char *op)
{
        struct audit_buffer *ab;
        struct audit_krule *rule = audit_mark->rule;

        if (!audit_enabled)
                return;
        ab = audit_log_start(NULL, GFP_NOFS, AUDIT_CONFIG_CHANGE);
        if (unlikely(!ab))
                return;
        audit_log_format(ab, "auid=%u ses=%u op=",
                         from_kuid(&init_user_ns, audit_get_loginuid(current)),
                         audit_get_sessionid(current));
        audit_log_string(ab, op);
        audit_log_format(ab, " path=");
        audit_log_untrustedstring(ab, audit_mark->path);
        audit_log_key(ab, rule->filterkey);
        audit_log_format(ab, " list=%d res=1", rule->listnr);
        audit_log_end(ab);
}

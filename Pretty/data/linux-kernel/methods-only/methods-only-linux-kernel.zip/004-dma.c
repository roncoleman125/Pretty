static int proc_dma_show(struct seq_file *m, void *v)
{
        int i;

        for (i = 0 ; i < MAX_DMA_CHANNELS ; i++) {
                if (dma_chan_busy[i].lock) {
                        seq_printf(m, "%2d: %s\n", i,
                                   dma_chan_busy[i].device_id);
                }
        }
        return 0;
}

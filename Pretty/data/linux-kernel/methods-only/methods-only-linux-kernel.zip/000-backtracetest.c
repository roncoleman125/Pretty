static void backtrace_test_normal(void)
{
        pr_info("Testing a backtrace from process context.\n");
        pr_info("The following trace is a kernel self test and not a bug!\n");

        dump_stack();
}

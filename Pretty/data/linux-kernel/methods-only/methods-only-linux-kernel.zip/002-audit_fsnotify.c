char *audit_mark_path(struct audit_fsnotify_mark *mark)
{
        return mark->path;
}

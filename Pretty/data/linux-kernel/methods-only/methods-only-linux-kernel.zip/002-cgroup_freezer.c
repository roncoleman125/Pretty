static struct freezer *parent_freezer(struct freezer *freezer)
{
        return css_freezer(freezer->css.parent);
}

static void put_uts(struct ctl_table *table, int write, void *which)
{
        if (!write)
                up_read(&uts_sem);
        else
                up_write(&uts_sem);
}

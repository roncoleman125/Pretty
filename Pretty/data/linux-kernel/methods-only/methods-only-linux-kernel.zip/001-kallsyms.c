static inline int is_kernel_text(unsigned long addr)
{
        if ((addr >= (unsigned long)_stext && addr <= (unsigned long)_etext) ||
            arch_is_kernel_text(addr))
                return 1;
        return in_gate_area_no_mm(addr);
}

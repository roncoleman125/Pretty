static inline bool task_has_mempolicy(struct task_struct *task)
{
        return task->mempolicy;
}

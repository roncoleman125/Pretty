static void __acct_update_integrals(struct task_struct *tsk,
                                    cputime_t utime, cputime_t stime)
{
        cputime_t time, dtime;
        u64 delta;

        if (!likely(tsk->mm))
                return;

        time = stime + utime;
        dtime = time - tsk->acct_timexpd;
        /* Avoid division: cputime_t is often in nanoseconds already. */
        delta = cputime_to_nsecs(dtime);

        if (delta < TICK_NSEC)
                return;

        tsk->acct_timexpd = time;
        /*
         * Divide by 1024 to avoid overflow, and to avoid division.
         * The final unit reported to userspace is Mbyte-usecs,
         * the rest of the math is done in xacct_add_tsk.
         */
        tsk->acct_rss_mem1 += delta * get_mm_rss(tsk->mm) >> 10;
        tsk->acct_vm_mem1 += delta * tsk->mm->total_vm >> 10;
}

static async_cookie_t __async_schedule(async_func_t func, void *data, struct async_domain *domain)
{
        struct async_entry *entry;
        unsigned long flags;
        async_cookie_t newcookie;

        /* allow irq-off callers */
        entry = kzalloc(sizeof(struct async_entry), GFP_ATOMIC);

        /*
         * If we're out of memory or if there's too much work
         * pending already, we execute synchronously.
         */
        if (!entry || atomic_read(&entry_count) > MAX_WORK) {
                kfree(entry);
                spin_lock_irqsave(&async_lock, flags);
                newcookie = next_cookie++;
                spin_unlock_irqrestore(&async_lock, flags);

                /* low on memory.. run synchronously */
                func(data, newcookie);
                return newcookie;
        }
        INIT_LIST_HEAD(&entry->domain_list);
        INIT_LIST_HEAD(&entry->global_list);
        INIT_WORK(&entry->work, async_run_entry_fn);
        entry->func = func;
        entry->data = data;
        entry->domain = domain;

        spin_lock_irqsave(&async_lock, flags);

        /* allocate cookie and queue */
        newcookie = entry->cookie = next_cookie++;

        list_add_tail(&entry->domain_list, &domain->pending);
        if (domain->registered)
                list_add_tail(&entry->global_list, &async_global_pending);

        atomic_inc(&entry_count);
        spin_unlock_irqrestore(&async_lock, flags);

        /* mark that this task has queued an async job, used by module init */
        current->flags |= PF_USED_ASYNC;

        /* schedule for execution */
        queue_work(system_unbound_wq, &entry->work);

        return newcookie;
}

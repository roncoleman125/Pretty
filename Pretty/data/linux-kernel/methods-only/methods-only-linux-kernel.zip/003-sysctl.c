static void warn_sysctl_write(struct ctl_table *table)
{
        pr_warn_once("%s wrote to %s when file position was not 0!\n"
                "This will not be supported in the future. To silence this\n"
                "warning, set kernel.sysctl_writes_strict = -1\n",
                current->comm, table->procname);
}

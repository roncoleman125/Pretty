static inline int mk_pid(struct pid_namespace *pid_ns,
                struct pidmap *map, int off)
{
        return (map - pid_ns->pidmap)*BITS_PER_PAGE + off;
}

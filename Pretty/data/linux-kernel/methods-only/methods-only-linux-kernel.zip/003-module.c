static __always_inline int
mod_tree_comp(void *key, struct latch_tree_node *n)
{
        unsigned long val = (unsigned long)key;
        unsigned long start, end;

        start = __mod_tree_val(n);
        if (val < start)
                return -1;

        end = start + __mod_tree_size(n);
        if (val >= end)
                return 1;

        return 0;
}

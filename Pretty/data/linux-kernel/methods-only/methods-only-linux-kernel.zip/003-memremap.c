/**
 * memremap() - remap an iomem_resource as cacheable memory
 * @offset: iomem resource start address
 * @size: size of remap
 * @flags: any of MEMREMAP_WB, MEMREMAP_WT and MEMREMAP_WC
 *
 * memremap() is "ioremap" for cases where it is known that the resource
 * being mapped does not have i/o side effects and the __iomem
 * annotation is not applicable. In the case of multiple flags, the different
 * mapping types will be attempted in the order listed below until one of
 * them succeeds.
 *
 * MEMREMAP_WB - matches the default mapping for System RAM on
 * the architecture.  This is usually a read-allocate write-back cache.
 * Morever, if MEMREMAP_WB is specified and the requested remap region is RAM
 * memremap() will bypass establishing a new mapping and instead return
 * a pointer into the direct map.
 *
 * MEMREMAP_WT - establish a mapping whereby writes either bypass the
 * cache or are written through to memory and never exist in a
 * cache-dirty state with respect to program visibility.  Attempts to
 * map System RAM with this mapping type will fail.
 *
 * MEMREMAP_WC - establish a writecombine mapping, whereby writes may
 * be coalesced together (e.g. in the CPU's write buffers), but is otherwise
 * uncached. Attempts to map System RAM with this mapping type will fail.
 */
void *memremap(resource_size_t offset, size_t size, unsigned long flags)
{
        int is_ram = region_intersects(offset, size,
                                       IORESOURCE_SYSTEM_RAM, IORES_DESC_NONE);
        void *addr = NULL;

        if (!flags)
                return NULL;

        if (is_ram == REGION_MIXED) {
                WARN_ONCE(1, "memremap attempted on mixed range %pa size: %#lx\n",
                                &offset, (unsigned long) size);
                return NULL;
        }

        /* Try all mapping types requested until one returns non-NULL */
        if (flags & MEMREMAP_WB) {
                /*
                 * MEMREMAP_WB is special in that it can be satisifed
                 * from the direct map.  Some archs depend on the
                 * capability of memremap() to autodetect cases where
                 * the requested range is potentially in System RAM.
                 */
                if (is_ram == REGION_INTERSECTS)
                        addr = try_ram_remap(offset, size);
                if (!addr)
                        addr = arch_memremap_wb(offset, size);
        }

        /*
         * If we don't have a mapping yet and other request flags are
         * present then we will be attempting to establish a new virtual
         * address mapping.  Enforce that this mapping is not aliasing
         * System RAM.
         */
        if (!addr && is_ram == REGION_INTERSECTS && flags != MEMREMAP_WB) {
                WARN_ONCE(1, "memremap attempted on ram %pa size: %#lx\n",
                                &offset, (unsigned long) size);
                return NULL;
        }

        if (!addr && (flags & MEMREMAP_WT))
                addr = ioremap_wt(offset, size);

        if (!addr && (flags & MEMREMAP_WC))
                addr = ioremap_wc(offset, size);

        return addr;
}

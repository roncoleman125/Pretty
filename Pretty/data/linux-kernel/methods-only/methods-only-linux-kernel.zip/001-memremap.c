static void *arch_memremap_wb(resource_size_t offset, unsigned long size)
{
        return (__force void *)ioremap_cache(offset, size);
}

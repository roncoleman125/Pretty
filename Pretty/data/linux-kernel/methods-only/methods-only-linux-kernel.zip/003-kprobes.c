static void free_insn_page(void *page)
{
        module_memfree(page);
}

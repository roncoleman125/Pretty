static int copy_user_segment_list(struct kimage *image,
                                  unsigned long nr_segments,
                                  struct kexec_segment __user *segments)
{
        int ret;
        size_t segment_bytes;

        /* Read in the segments */
        image->nr_segments = nr_segments;
        segment_bytes = nr_segments * sizeof(*segments);
        ret = copy_from_user(image->segment, segments, segment_bytes);
        if (ret)
                ret = -EFAULT;

        return ret;
}

/*
 * Get symbol type information. This is encoded as a single char at the
 * beginning of the symbol name.
 */
static char kallsyms_get_symbol_type(unsigned int off)
{
        /*
         * Get just the first code, look it up in the token table,
         * and return the first char from this token.
         */
        return kallsyms_token_table[kallsyms_token_index[kallsyms_names[off + 1]]];
}

/**
 * freeze_task - send a freeze request to given task
 * @p: task to send the request to
 *
 * If @p is freezing, the freeze request is sent either by sending a fake
 * signal (if it's not a kernel thread) or waking it up (if it's a kernel
 * thread).
 *
 * RETURNS:
 * %false, if @p is not freezing or already frozen; %true, otherwise
 */
bool freeze_task(struct task_struct *p)
{
        unsigned long flags;

        /*
         * This check can race with freezer_do_not_count, but worst case that
         * will result in an extra wakeup being sent to the task.  It does not
         * race with freezer_count(), the barriers in freezer_count() and
         * freezer_should_skip() ensure that either freezer_count() sees
         * freezing == true in try_to_freeze() and freezes, or
         * freezer_should_skip() sees !PF_FREEZE_SKIP and freezes the task
         * normally.
         */
        if (freezer_should_skip(p))
                return false;

        spin_lock_irqsave(&freezer_lock, flags);
        if (!freezing(p) || frozen(p)) {
                spin_unlock_irqrestore(&freezer_lock, flags);
                return false;
        }

        if (!(p->flags & PF_KTHREAD))
                fake_signal_wake_up(p);
        else
                wake_up_state(p, TASK_INTERRUPTIBLE);

        spin_unlock_irqrestore(&freezer_lock, flags);
        return true;
}

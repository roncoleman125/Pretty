static inline void check_kparam_locked(struct module *mod)
{
}

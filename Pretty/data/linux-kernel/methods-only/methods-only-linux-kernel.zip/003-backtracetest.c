static void backtrace_test_saved(void)
{
        struct stack_trace trace;
        unsigned long entries[8];

        pr_info("Testing a saved backtrace.\n");
        pr_info("The following trace is a kernel self test and not a bug!\n");

        trace.nr_entries = 0;
        trace.max_entries = ARRAY_SIZE(entries);
        trace.entries = entries;
        trace.skip = 0;

        save_stack_trace(&trace);
        print_stack_trace(&trace, 0);
}

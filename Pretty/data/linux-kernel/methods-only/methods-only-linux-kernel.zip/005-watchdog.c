static int __init softlockup_all_cpu_backtrace_setup(char *str)
{
        sysctl_softlockup_all_cpu_backtrace =
                !!simple_strtol(str, NULL, 0);
        return 1;
}

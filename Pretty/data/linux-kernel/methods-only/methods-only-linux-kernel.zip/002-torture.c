/*
 * Clean up after online/offline testing.
 */
static void torture_onoff_cleanup(void)
{
//#ifdef CONFIG_HOTPLUG_CPU
        if (onoff_task == NULL)
                return;
        VERBOSE_TOROUT_STRING("Stopping torture_onoff task");
        kthread_stop(onoff_task);
        onoff_task = NULL;
//#endif /* #ifdef CONFIG_HOTPLUG_CPU */
}

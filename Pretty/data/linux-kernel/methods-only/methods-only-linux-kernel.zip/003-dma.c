void free_dma(unsigned int dmanr)
{
}

static bool context_tracking_recursion_enter(void)
{
        int recursion;

        recursion = __this_cpu_inc_return(context_tracking.recursion);
        if (recursion == 1)
                return true;

        WARN_ONCE((recursion < 1), "Invalid context tracking recursion value %d\n", recursion);
        __this_cpu_dec(context_tracking.recursion);

        return false;
}

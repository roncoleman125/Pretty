int snprint_stack_trace(char *buf, size_t size,
                        struct stack_trace *trace, int spaces)
{
        int i;
        unsigned long ip;
        int generated;
        int total = 0;

        if (WARN_ON(!trace->entries))
                return 0;

        for (i = 0; i < trace->nr_entries; i++) {
                ip = trace->entries[i];
                generated = snprintf(buf, size, "%*c[<%p>] %pS\n",
                                1 + spaces, ' ', (void *) ip, (void *) ip);

                total += generated;

                /* Assume that generated isn't a negative number */
                if (generated >= size) {
                        buf += size;
                        size = 0;
                } else {
                        buf += generated;
                        size -= generated;
                }
        }

        return total;
}

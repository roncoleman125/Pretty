static inline void audit_free_rule(struct audit_entry *e)
{
        int i;
        struct audit_krule *erule = &e->rule;

        /* some rules don't have associated watches */
        if (erule->watch)
                audit_put_watch(erule->watch);
        if (erule->fields)
                for (i = 0; i < erule->field_count; i++)
                        audit_free_lsm_field(&erule->fields[i]);
        kfree(erule->fields);
        kfree(erule->filterkey);
        kfree(e);
}

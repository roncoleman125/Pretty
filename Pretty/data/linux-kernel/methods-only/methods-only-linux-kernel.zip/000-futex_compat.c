/*
 * Fetch a robust-list pointer. Bit 0 signals PI futexes:
 */
static inline int
fetch_robust_entry(compat_uptr_t *uentry, struct robust_list __user **entry,
                   compat_uptr_t __user *head, unsigned int *pi)
{
        if (get_user(*uentry, head))
                return -EFAULT;

        *entry = compat_ptr((*uentry) & ~1);
        *pi = (unsigned int)(*uentry) & 1;

        return 0;
}

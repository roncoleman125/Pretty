static struct page *kimage_alloc_pages(gfp_t gfp_mask, unsigned int order)
{
        struct page *pages;

        pages = alloc_pages(gfp_mask, order);
        if (pages) {
                unsigned int count, i;

                pages->mapping = NULL;
                set_page_private(pages, order);
                count = 1 << order;
                for (i = 0; i < count; i++)
                        SetPageReserved(pages + i);
        }

        return pages;
}

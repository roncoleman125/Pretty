/*
 * Clone a new ns copying an original utsname, setting refcount to 1
 * @old_ns: namespace to clone
 * Return ERR_PTR(-ENOMEM) on error (failure to kmalloc), new ns otherwise
 */
static struct uts_namespace *clone_uts_ns(struct user_namespace *user_ns,
                                          struct uts_namespace *old_ns)
{
        struct uts_namespace *ns;
        int err;

        ns = create_uts_ns();
        if (!ns)
                return ERR_PTR(-ENOMEM);

        err = ns_alloc_inum(&ns->ns);
        if (err) {
                kfree(ns);
                return ERR_PTR(err);
        }

        ns->ns.ops = &utsns_operations;

        down_read(&uts_sem);
        memcpy(&ns->name, &old_ns->name, sizeof(ns->name));
        ns->user_ns = get_user_ns(user_ns);
        up_read(&uts_sem);
        return ns;
}

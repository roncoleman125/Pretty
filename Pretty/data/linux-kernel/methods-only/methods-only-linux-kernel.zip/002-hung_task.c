static void check_hung_task(struct task_struct *t, unsigned long timeout)
{
        unsigned long switch_count = t->nvcsw + t->nivcsw;

        /*
         * Ensure the task is not frozen.
         * Also, skip vfork and any other user process that freezer should skip.
         */
        if (unlikely(t->flags & (PF_FROZEN | PF_FREEZER_SKIP)))
            return;

        /*
         * When a freshly created task is scheduled once, changes its state to
         * TASK_UNINTERRUPTIBLE without having ever been switched out once, it
         * musn't be checked.
         */
        if (unlikely(!switch_count))
                return;

        if (switch_count != t->last_switch_count) {
                t->last_switch_count = switch_count;
                return;
        }

        trace_sched_process_hang(t);

        if (!sysctl_hung_task_warnings)
                return;

        if (sysctl_hung_task_warnings > 0)
                sysctl_hung_task_warnings--;

        /*
         * Ok, the task did not get scheduled for more than 2 minutes,
         * complain:
         */
        pr_err("INFO: task %s:%d blocked for more than %ld seconds.\n",
                t->comm, t->pid, timeout);
        pr_err("      %s %s %.*s\n",
                print_tainted(), init_utsname()->release,
                (int)strcspn(init_utsname()->version, " "),
                init_utsname()->version);
        pr_err("\"echo 0 > /proc/sys/kernel/hung_task_timeout_secs\""
                " disables this message.\n");
        sched_show_task(t);
        debug_show_held_locks(t);

        touch_nmi_watchdog();

        if (sysctl_hung_task_panic) {
                trigger_all_cpu_backtrace();
                panic("hung_task: blocked tasks");
        }
}

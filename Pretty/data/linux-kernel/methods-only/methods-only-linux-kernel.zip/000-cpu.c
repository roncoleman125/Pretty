/**
 * cpuhp_invoke_callback _ Invoke the callbacks for a given state
 * @cpu:        The cpu for which the callback should be invoked
 * @step:       The step in the state machine
 * @cb:         The callback function to invoke
 *
 * Called from cpu hotplug and from the state register machinery
 */
static int cpuhp_invoke_callback(unsigned int cpu, enum cpuhp_state step,
                                 int (*cb)(unsigned int))
{
        struct cpuhp_cpu_state *st = per_cpu_ptr(&cpuhp_state, cpu);
        int ret = 0;

        if (cb) {
                trace_cpuhp_enter(cpu, st->target, step, cb);
                ret = cb(cpu);
                trace_cpuhp_exit(cpu, st->state, step, ret);
        }
        return ret;
}

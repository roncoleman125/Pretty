static void devm_memremap_release(struct device *dev, void *res)
{
        memunmap(*(void **)res);
}

static int compat_put_timex(struct compat_timex __user *utp, struct timex *txc)
{
        if (!access_ok(VERIFY_WRITE, utp, sizeof(struct compat_timex)) ||
                        __put_user(txc->modes, &utp->modes) ||
                        __put_user(txc->offset, &utp->offset) ||
                        __put_user(txc->freq, &utp->freq) ||
                        __put_user(txc->maxerror, &utp->maxerror) ||
                        __put_user(txc->esterror, &utp->esterror) ||
                        __put_user(txc->status, &utp->status) ||
                        __put_user(txc->constant, &utp->constant) ||
                        __put_user(txc->precision, &utp->precision) ||
                        __put_user(txc->tolerance, &utp->tolerance) ||
                        __put_user(txc->time.tv_sec, &utp->time.tv_sec) ||
                        __put_user(txc->time.tv_usec, &utp->time.tv_usec) ||
                        __put_user(txc->tick, &utp->tick) ||
                        __put_user(txc->ppsfreq, &utp->ppsfreq) ||
                        __put_user(txc->jitter, &utp->jitter) ||
                        __put_user(txc->shift, &utp->shift) ||
                        __put_user(txc->stabil, &utp->stabil) ||
                        __put_user(txc->jitcnt, &utp->jitcnt) ||
                        __put_user(txc->calcnt, &utp->calcnt) ||
                        __put_user(txc->errcnt, &utp->errcnt) ||
                        __put_user(txc->stbcnt, &utp->stbcnt) ||
                        __put_user(txc->tai, &utp->tai))
                return -EFAULT;
        return 0;
}

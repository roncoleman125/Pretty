void groups_free(struct group_info *group_info)
{
        if (group_info->blocks[0] != group_info->small_block) {
                int i;
                for (i = 0; i < group_info->nblocks; i++)
                        free_page((unsigned long)group_info->blocks[i]);
        }
        kfree(group_info);
}

static int kp_pre_handler(struct kprobe *p, struct pt_regs *regs)
{
        preh_val = (rand1 / div_factor);
        return 0;
}

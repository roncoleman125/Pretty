/*
 * Preemption is disabled here to make sure the cond_func is called under the
 * same condtions in UP and SMP.
 */
void on_each_cpu_cond(bool (*cond_func)(int cpu, void *info),
                      smp_call_func_t func, void *info, bool wait,
                      gfp_t gfp_flags)
{
        unsigned long flags;

        preempt_disable();
        if (cond_func(0, info)) {
                local_irq_save(flags);
                func(info);
                local_irq_restore(flags);
        }
        preempt_enable();
}

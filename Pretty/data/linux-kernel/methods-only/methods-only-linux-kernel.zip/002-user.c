static struct user_struct *uid_hash_find(kuid_t uid, struct hlist_head *hashent)
{
        struct user_struct *user;

        hlist_for_each_entry(user, hashent, uidhash_node) {
                if (uid_eq(user->uid, uid)) {
                        atomic_inc(&user->__count);
                        return user;
                }
        }

        return NULL;
}

/* The caller must have pinned the task */
static struct file *
get_file_raw_ptr(struct task_struct *task, unsigned int idx)
{
        struct file *file = NULL;

        task_lock(task);
        rcu_read_lock();

        if (task->files)
                file = fcheck_files(task->files, idx);

        rcu_read_unlock();
        task_unlock(task);

        return file;
}

/* a simple Shell sort */
static void groups_sort(struct group_info *group_info)
{
        int base, max, stride;
        int gidsetsize = group_info->ngroups;

        for (stride = 1; stride < gidsetsize; stride = 3 * stride + 1)
                ; /* nothing */
        stride /= 3;

        while (stride) {
                max = gidsetsize - stride;
                for (base = 0; base < max; base++) {
                        int left = base;
                        int right = left + stride;
                        kgid_t tmp = GROUP_AT(group_info, right);

                        while (left >= 0 && gid_gt(GROUP_AT(group_info, left), tmp)) {
                                GROUP_AT(group_info, right) =
                                    GROUP_AT(group_info, left);
                                right = left;
                                left -= stride;
                        }
                        GROUP_AT(group_info, right) = tmp;
                }
                stride /= 3;
        }
}

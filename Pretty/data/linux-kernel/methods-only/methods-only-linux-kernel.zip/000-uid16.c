SYSCALL_DEFINE3(chown16, const char __user *, filename, old_uid_t, user, old_gid_t, group)
{
        return sys_chown(filename, low2highuid(user), low2highgid(group));
}

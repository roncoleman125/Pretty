/*
 * Execute random CPU-hotplug operations at the interval specified
 * by the onoff_interval.
 */
static int
torture_onoff(void *arg)
{
        int cpu;
        unsigned long delta;
        int maxcpu = -1;
        DEFINE_TORTURE_RANDOM(rand);
        int ret;
        unsigned long starttime;

        VERBOSE_TOROUT_STRING("torture_onoff task started");
        for_each_online_cpu(cpu)
                maxcpu = cpu;
        WARN_ON(maxcpu < 0);
        if (onoff_holdoff > 0) {
                VERBOSE_TOROUT_STRING("torture_onoff begin holdoff");
                schedule_timeout_interruptible(onoff_holdoff);
                VERBOSE_TOROUT_STRING("torture_onoff end holdoff");
        }
        while (!torture_must_stop()) {
                cpu = (torture_random(&rand) >> 4) % (maxcpu + 1);
                if (cpu_online(cpu) && cpu_is_hotpluggable(cpu)) {
                        if (verbose)
                                pr_alert("%s" TORTURE_FLAG
                                         "torture_onoff task: offlining %d\n",
                                         torture_type, cpu);
                        starttime = jiffies;
                        n_offline_attempts++;
                        ret = cpu_down(cpu);
                        if (ret) {
                                if (verbose)
                                        pr_alert("%s" TORTURE_FLAG
                                                 "torture_onoff task: offline %d failed: errno %d\n",
                                                 torture_type, cpu, ret);
                        } else {
                                if (verbose)
                                        pr_alert("%s" TORTURE_FLAG
                                                 "torture_onoff task: offlined %d\n",
                                                 torture_type, cpu);
                                n_offline_successes++;
                                delta = jiffies - starttime;
                                sum_offline += delta;
                                if (min_offline < 0) {
                                        min_offline = delta;
                                        max_offline = delta;
                                }
                                if (min_offline > delta)
                                        min_offline = delta;
                                if (max_offline < delta)
                                        max_offline = delta;
                        }
                } else if (cpu_is_hotpluggable(cpu)) {
                        if (verbose)
                                pr_alert("%s" TORTURE_FLAG
                                         "torture_onoff task: onlining %d\n",
                                         torture_type, cpu);
                        starttime = jiffies;
                        n_online_attempts++;
                        ret = cpu_up(cpu);
                        if (ret) {
                                if (verbose)
                                        pr_alert("%s" TORTURE_FLAG
                                                 "torture_onoff task: online %d failed: errno %d\n",
                                                 torture_type, cpu, ret);
                        } else {
                                if (verbose)
                                        pr_alert("%s" TORTURE_FLAG
                                                 "torture_onoff task: onlined %d\n",
                                                 torture_type, cpu);
                                n_online_successes++;
                                delta = jiffies - starttime;
                                sum_online += delta;
                                if (min_online < 0) {
                                        min_online = delta;
                                        max_online = delta;
                                }
                                if (min_online > delta)
                                        min_online = delta;
                                if (max_online < delta)
                                        max_online = delta;
                        }
                }
                schedule_timeout_interruptible(onoff_interval);
        }
        torture_kthread_stopping("torture_onoff");
        return 0;
}

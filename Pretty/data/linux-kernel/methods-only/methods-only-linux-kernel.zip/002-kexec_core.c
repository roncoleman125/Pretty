struct kimage *do_kimage_alloc_init(void)
{
        struct kimage *image;

        /* Allocate a controlling structure */
        image = kzalloc(sizeof(*image), GFP_KERNEL);
        if (!image)
                return NULL;

        image->head = 0;
        image->entry = &image->head;
        image->last_entry = &image->head;
        image->control_page = ~0; /* By default this does not apply */
        image->type = KEXEC_TYPE_DEFAULT;

        /* Initialize the list of control pages */
        INIT_LIST_HEAD(&image->control_pages);

        /* Initialize the list of destination pages */
        INIT_LIST_HEAD(&image->dest_pages);

        /* Initialize the list of unusable pages */
        INIT_LIST_HEAD(&image->unusable_pages);

        return image;
}

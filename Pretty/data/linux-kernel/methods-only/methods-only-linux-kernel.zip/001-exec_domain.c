static int execdomains_proc_open(struct inode *inode, struct file *file)
{
        return single_open(file, execdomains_proc_show, NULL);
}

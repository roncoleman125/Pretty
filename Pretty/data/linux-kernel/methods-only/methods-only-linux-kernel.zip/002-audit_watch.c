static void audit_get_parent(struct audit_parent *parent)
{
        if (likely(parent))
                fsnotify_get_mark(&parent->mark);
}

/* current uevent sequence number */
static ssize_t uevent_seqnum_show(struct kobject *kobj,
                                  struct kobj_attribute *attr, char *buf)
{
        return sprintf(buf, "%llu\n", (unsigned long long)uevent_seqnum);
}

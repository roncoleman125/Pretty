static __always_inline void csd_lock(struct call_single_data *csd)
{
        csd_lock_wait(csd);
        csd->flags |= CSD_FLAG_LOCK;

        /*
         * prevent CPU from reordering the above assignment
         * to ->flags with any subsequent assignments to other
         * fields of the specified call_single_data structure:
         */
        smp_wmb();
}

static int is_ksym_addr(unsigned long addr)
{
        if (all_var)
                return is_kernel(addr);

        return is_kernel_text(addr) || is_kernel_inittext(addr);
}

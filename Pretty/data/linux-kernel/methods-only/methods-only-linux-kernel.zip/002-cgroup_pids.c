static struct cgroup_subsys_state *
pids_css_alloc(struct cgroup_subsys_state *parent)
{
        struct pids_cgroup *pids;

        pids = kzalloc(sizeof(struct pids_cgroup), GFP_KERNEL);
        if (!pids)
                return ERR_PTR(-ENOMEM);

        pids->limit = PIDS_MAX;
        atomic64_set(&pids->counter, 0);
        return &pids->css;
}

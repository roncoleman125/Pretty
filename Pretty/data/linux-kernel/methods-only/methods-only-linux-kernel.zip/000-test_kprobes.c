static noinline u32 kprobe_target(u32 value)
{
        return (value / div_factor);
}

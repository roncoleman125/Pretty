static int __init utsname_sysctl_init(void)
{
        register_sysctl_table(uts_root_table);
        return 0;
}

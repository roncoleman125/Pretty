void sort_range(struct range *range, int nr_range)
{
        /* sort them */
        sort(range, nr_range, sizeof(struct range), cmp_range, NULL);
}

/*
 * padata_get_next - Get the next object that needs serialization.
 *
 * Return values are:
 *
 * A pointer to the control struct of the next object that needs
 * serialization, if present in one of the percpu reorder queues.
 *
 * NULL, if all percpu reorder queues are empty.
 *
 * -EINPROGRESS, if the next object that needs serialization will
 *  be parallel processed by another cpu and is not yet present in
 *  the cpu's reorder queue.
 *
 * -ENODATA, if this cpu has to do the parallel processing for
 *  the next object.
 */
static struct padata_priv *padata_get_next(struct parallel_data *pd)
{
        int cpu, num_cpus;
        unsigned int next_nr, next_index;
        struct padata_parallel_queue *next_queue;
        struct padata_priv *padata;
        struct padata_list *reorder;

        num_cpus = cpumask_weight(pd->cpumask.pcpu);

        /*
         * Calculate the percpu reorder queue and the sequence
         * number of the next object.
         */
        next_nr = pd->processed;
        next_index = next_nr % num_cpus;
        cpu = padata_index_to_cpu(pd, next_index);
        next_queue = per_cpu_ptr(pd->pqueue, cpu);

        padata = NULL;

        reorder = &next_queue->reorder;

        if (!list_empty(&reorder->list)) {
                padata = list_entry(reorder->list.next,
                                    struct padata_priv, list);

                spin_lock(&reorder->lock);
                list_del_init(&padata->list);
                atomic_dec(&pd->reorder_objects);
                spin_unlock(&reorder->lock);

                pd->processed++;

                goto out;
        }

        if (__this_cpu_read(pd->pqueue->cpu_index) == next_queue->cpu_index) {
                padata = ERR_PTR(-ENODATA);
                goto out;
        }

        padata = ERR_PTR(-EINPROGRESS);
out:
        return padata;
}

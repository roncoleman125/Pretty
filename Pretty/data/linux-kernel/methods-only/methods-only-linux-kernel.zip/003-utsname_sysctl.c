/*
 * Notify userspace about a change in a certain entry of uts_kern_table,
 * identified by the parameter proc.
 */
void uts_proc_notify(enum uts_proc proc)
{
        struct ctl_table *table = &uts_kern_table[proc];

        proc_sys_poll_notify(table->poll);
}

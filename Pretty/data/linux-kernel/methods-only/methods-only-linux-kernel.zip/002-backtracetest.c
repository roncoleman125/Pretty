static void backtrace_test_irq(void)
{
        pr_info("Testing a backtrace from irq context.\n");
        pr_info("The following trace is a kernel self test and not a bug!\n");

        init_completion(&backtrace_work);
        tasklet_schedule(&backtrace_tasklet);
        wait_for_completion(&backtrace_work);
}

/*
 * If we started walking pids at 'base', is 'a' seen before 'b'?
 */
static int pid_before(int base, int a, int b)
{
        /*
         * This is the same as saying
         *
         * (a - base + MAXUINT) % MAXUINT < (b - base + MAXUINT) % MAXUINT
         * and that mapping orders 'a' and 'b' with respect to 'base'.
         */
        return (unsigned)(a - base) < (unsigned)(b - base);
}

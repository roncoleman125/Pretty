static void acct_put(struct bsd_acct_struct *p)
{
        if (atomic_long_dec_and_test(&p->count))
                kfree_rcu(p, rcu);
}

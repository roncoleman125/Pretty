/**
 *      relay_mmap_buf: - mmap channel buffer to process address space
 *      @buf: relay channel buffer
 *      @vma: vm_area_struct describing memory to be mapped
 *
 *      Returns 0 if ok, negative on error
 *
 *      Caller should already have grabbed mmap_sem.
 */
static int relay_mmap_buf(struct rchan_buf *buf, struct vm_area_struct *vma)
{
        unsigned long length = vma->vm_end - vma->vm_start;
        struct file *filp = vma->vm_file;

        if (!buf)
                return -EBADF;

        if (length != (unsigned long)buf->chan->alloc_size)
                return -EINVAL;

        vma->vm_ops = &relay_file_mmap_ops;
        vma->vm_flags |= VM_DONTEXPAND;
        vma->vm_private_data = buf;
        buf->chan->cb->buf_mapped(buf, filp);

        return 0;
}

static void r_stop(struct seq_file *m, void *v)
        __releases(resource_lock)
{
        read_unlock(&resource_lock);
}

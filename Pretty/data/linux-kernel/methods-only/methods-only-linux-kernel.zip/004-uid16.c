SYSCALL_DEFINE1(setgid16, old_gid_t, gid)
{
        return sys_setgid(low2highgid(gid));
}

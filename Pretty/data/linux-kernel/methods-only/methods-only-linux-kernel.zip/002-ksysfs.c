static ssize_t uevent_helper_store(struct kobject *kobj,
                                   struct kobj_attribute *attr,
                                   const char *buf, size_t count)
{
        if (count+1 > UEVENT_HELPER_PATH_LEN)
                return -ENOENT;
        memcpy(uevent_helper, buf, count);
        uevent_helper[count] = '\0';
        if (count && uevent_helper[count-1] == '\n')
                uevent_helper[count-1] = '\0';
        return count;
}

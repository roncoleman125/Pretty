void free_uts_ns(struct kref *kref)
{
        struct uts_namespace *ns;

        ns = container_of(kref, struct uts_namespace, kref);
        put_user_ns(ns->user_ns);
        ns_free_inum(&ns->ns);
        kfree(ns);
}

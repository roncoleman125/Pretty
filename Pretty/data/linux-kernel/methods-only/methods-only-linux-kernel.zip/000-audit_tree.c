static struct audit_tree *alloc_tree(const char *s)
{
        struct audit_tree *tree;

        tree = kmalloc(sizeof(struct audit_tree) + strlen(s) + 1, GFP_KERNEL);
        if (tree) {
                atomic_set(&tree->count, 1);
                tree->goner = 0;
                INIT_LIST_HEAD(&tree->chunks);
                INIT_LIST_HEAD(&tree->rules);
                INIT_LIST_HEAD(&tree->list);
                INIT_LIST_HEAD(&tree->same_root);
                tree->root = NULL;
                strcpy(tree->pathname, s);
        }
        return tree;
}

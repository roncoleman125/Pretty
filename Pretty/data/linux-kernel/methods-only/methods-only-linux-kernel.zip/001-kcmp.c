/*
 * 0 - equal, i.e. v1 = v2
 * 1 - less than, i.e. v1 < v2
 * 2 - greater than, i.e. v1 > v2
 * 3 - not equal but ordering unavailable (reserved for future)
 */
static int kcmp_ptr(void *v1, void *v2, enum kcmp_type type)
{
        long t1, t2;

        t1 = kptr_obfuscate((long)v1, type);
        t2 = kptr_obfuscate((long)v2, type);

        return (t1 < t2) | ((t1 > t2) << 1);
}

static ssize_t bin_uuid(struct file *file,
        void __user *oldval, size_t oldlen, void __user *newval, size_t newlen)
{
        ssize_t result, copied = 0;

        /* Only supports reads */
        if (oldval && oldlen) {
                char buf[UUID_STRING_LEN + 1];
                uuid_be uuid;

                result = kernel_read(file, 0, buf, sizeof(buf) - 1);
                if (result < 0)
                        goto out;

                buf[result] = '\0';

                result = -EIO;
                if (uuid_be_to_bin(buf, &uuid))
                        goto out;

                if (oldlen > 16)
                        oldlen = 16;

                result = -EFAULT;
                if (copy_to_user(oldval, &uuid, oldlen))
                        goto out;

                copied = oldlen;
        }
        result = copied;
out:
        return result;
}

static ssize_t bin_dn_node_address(struct file *file,
        void __user *oldval, size_t oldlen, void __user *newval, size_t newlen)
{
        ssize_t result, copied = 0;

        if (oldval && oldlen) {
                char buf[15], *nodep;
                unsigned long area, node;
                __le16 dnaddr;

                result = kernel_read(file, 0, buf, sizeof(buf) - 1);
                if (result < 0)
                        goto out;

                buf[result] = '\0';

                /* Convert the decnet address to binary */
                result = -EIO;
                nodep = strchr(buf, '.');
                if (!nodep)
                        goto out;
                ++nodep;

                area = simple_strtoul(buf, NULL, 10);
                node = simple_strtoul(nodep, NULL, 10);

                result = -EIO;
                if ((area > 63)||(node > 1023))
                        goto out;

                dnaddr = cpu_to_le16((area << 10) | node);

                result = -EFAULT;
                if (put_user(dnaddr, (__le16 __user *)oldval))
                        goto out;

                copied = sizeof(dnaddr);
        }

        if (newval && newlen) {
                __le16 dnaddr;
                char buf[15];
                int len;

                result = -EINVAL;
                if (newlen != sizeof(dnaddr))
                        goto out;

                result = -EFAULT;
                if (get_user(dnaddr, (__le16 __user *)newval))
                        goto out;

                len = scnprintf(buf, sizeof(buf), "%hu.%hu",
                                le16_to_cpu(dnaddr) >> 10,
                                le16_to_cpu(dnaddr) & 0x3ff);

                result = kernel_write(file, buf, len, 0);
                if (result < 0)
                        goto out;
        }

        result = copied;
out:
        return result;
}

static void *r_next(struct seq_file *m, void *v, loff_t *pos)
{
        struct resource *p = v;
        (*pos)++;
        return (void *)next_resource(p, false);
}

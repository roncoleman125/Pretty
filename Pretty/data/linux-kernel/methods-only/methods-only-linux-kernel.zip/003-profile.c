int profile_handoff_task(struct task_struct *task)
{
        int ret;
        ret = atomic_notifier_call_chain(&task_free_notifier, 0, task);
        return (ret == NOTIFY_OK) ? 1 : 0;
}
